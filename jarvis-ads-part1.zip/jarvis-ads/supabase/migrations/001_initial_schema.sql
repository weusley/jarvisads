-- ═══════════════════════════════════════════════════════
-- JARVIS ADS — Complete Supabase Schema
-- Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── USERS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.users (
  id              UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email           TEXT NOT NULL UNIQUE,
  full_name       TEXT,
  role            TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  plan            TEXT NOT NULL DEFAULT 'starter' CHECK (plan IN ('starter', 'pro', 'agency')),
  stripe_customer_id TEXT,
  language        TEXT NOT NULL DEFAULT 'en' CHECK (language IN ('pt-BR', 'en', 'es')),
  affiliate_code  TEXT UNIQUE,
  referred_by     UUID REFERENCES public.users(id),
  affiliate_active BOOLEAN DEFAULT FALSE,
  avatar_url      TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all users" ON public.users
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── SUBSCRIPTIONS ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id                 UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  stripe_subscription_id  TEXT NOT NULL UNIQUE,
  stripe_price_id         TEXT,
  plan                    TEXT NOT NULL CHECK (plan IN ('starter', 'pro', 'agency')),
  status                  TEXT NOT NULL CHECK (status IN ('active', 'canceled', 'past_due', 'trialing', 'incomplete')),
  current_period_start    TIMESTAMPTZ,
  current_period_end      TIMESTAMPTZ,
  cancel_at_period_end    BOOLEAN DEFAULT FALSE,
  created_at              TIMESTAMPTZ DEFAULT NOW(),
  updated_at              TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subscription" ON public.subscriptions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all subscriptions" ON public.subscriptions
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── API KEYS (user-level) ────────────────────────────
CREATE TABLE IF NOT EXISTS public.api_keys (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  service_name  TEXT NOT NULL,
  encrypted_key TEXT NOT NULL,
  extra_data    JSONB,
  status        TEXT DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'error')),
  last_tested_at TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, service_name)
);

ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own api keys" ON public.api_keys
  FOR ALL USING (auth.uid() = user_id);

-- ─── SYSTEM API KEYS (admin-only) ────────────────────
CREATE TABLE IF NOT EXISTS public.system_api_keys (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  service_name      TEXT NOT NULL UNIQUE,
  encrypted_key     TEXT,
  extra_config      JSONB,
  status            TEXT DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'error')),
  enabled           BOOLEAN DEFAULT TRUE,
  calls_this_month  INTEGER DEFAULT 0,
  cost_estimate     DECIMAL(10,2) DEFAULT 0,
  last_tested_at    TIMESTAMPTZ,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.system_api_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only admins can manage system api keys" ON public.system_api_keys
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── PROJECTS ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.projects (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  product_url         TEXT NOT NULL,
  product_name        TEXT,
  brief_json          JSONB,
  platform_selection  TEXT CHECK (platform_selection IN ('facebook', 'google', 'both')),
  status              TEXT DEFAULT 'draft'
    CHECK (status IN ('draft','analyzing','strategy','creating','review','publishing','live')),
  current_step        INTEGER DEFAULT 1 CHECK (current_step BETWEEN 1 AND 6),
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own projects" ON public.projects
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all projects" ON public.projects
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── PROJECT INTELLIGENCE ─────────────────────────────
CREATE TABLE IF NOT EXISTS public.project_intelligence (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id            UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  semrush_data          JSONB,
  similarweb_data       JSONB,
  spyfu_data            JSONB,
  keyword_planner_data  JSONB,
  perplexity_insights   JSONB,
  fb_competitor_ads     JSONB,
  google_competitor_ads JSONB,
  vision_analysis       JSONB,
  last_updated_at       TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.project_intelligence ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own project intelligence" ON public.project_intelligence
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.projects WHERE id = project_id AND user_id = auth.uid())
  );

-- ─── COMPETITOR MONITORING ────────────────────────────
CREATE TABLE IF NOT EXISTS public.competitor_monitoring (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id          UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  competitor_domain   TEXT,
  new_ads_detected    INTEGER DEFAULT 0,
  alert_sent          BOOLEAN DEFAULT FALSE,
  checked_at          TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.competitor_monitoring ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own monitoring" ON public.competitor_monitoring
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.projects WHERE id = project_id AND user_id = auth.uid())
  );

-- ─── CREATIVES ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.creatives (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id  UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  type        TEXT NOT NULL CHECK (type IN ('text','image','video','voiceover')),
  platform    TEXT CHECK (platform IN ('facebook','google','both','general')),
  content_url TEXT,
  content_text TEXT,
  metadata    JSONB,
  approved    BOOLEAN DEFAULT FALSE,
  api_used    TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.creatives ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own creatives" ON public.creatives
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.projects WHERE id = project_id AND user_id = auth.uid())
  );

-- ─── CAMPAIGNS ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.campaigns (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id          UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  platform            TEXT NOT NULL CHECK (platform IN ('facebook','google','both')),
  fb_campaign_id      TEXT,
  google_campaign_id  TEXT,
  campaign_name       TEXT,
  status              TEXT DEFAULT 'draft' CHECK (status IN ('draft','active','paused','ended')),
  budget              DECIMAL(10,2),
  budget_type         TEXT CHECK (budget_type IN ('daily','lifetime')),
  performance_json    JSONB,
  published_at        TIMESTAMPTZ,
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own campaigns" ON public.campaigns
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.projects WHERE id = project_id AND user_id = auth.uid())
  );

-- ─── GOOGLE ADS CONNECTION ────────────────────────────
CREATE TABLE IF NOT EXISTS public.google_ads_connections (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id               UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE UNIQUE,
  customer_id           TEXT,
  account_name          TEXT,
  refresh_token_encrypted TEXT,
  currency              TEXT,
  timezone              TEXT,
  connected_at          TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.google_ads_connections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own google connection" ON public.google_ads_connections
  FOR ALL USING (auth.uid() = user_id);

-- ─── CHAT MESSAGES ───────────────────────────────────
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id      TEXT,
  user_id         UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  role            TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content         TEXT NOT NULL,
  attachments_json JSONB,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own chat messages" ON public.chat_messages
  FOR ALL USING (auth.uid() = user_id);

-- ─── AFFILIATES ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.affiliates (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id                 UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE UNIQUE,
  referral_code           TEXT NOT NULL UNIQUE,
  referral_link           TEXT NOT NULL,
  total_referrals         INTEGER DEFAULT 0,
  active_referrals        INTEGER DEFAULT 0,
  total_earned            DECIMAL(10,2) DEFAULT 0,
  pending_payout          DECIMAL(10,2) DEFAULT 0,
  payout_method           TEXT,
  payout_details_encrypted TEXT,
  joined_at               TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.affiliates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own affiliate" ON public.affiliates
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own affiliate payout" ON public.affiliates
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all affiliates" ON public.affiliates
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── AFFILIATE REFERRALS ──────────────────────────────
CREATE TABLE IF NOT EXISTS public.affiliate_referrals (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  affiliate_user_id UUID NOT NULL REFERENCES public.users(id),
  referred_user_id  UUID NOT NULL REFERENCES public.users(id),
  commission_amount DECIMAL(10,2),
  status            TEXT DEFAULT 'pending' CHECK (status IN ('pending','confirmed','paid','canceled')),
  stripe_charge_id  TEXT,
  paid_at           TIMESTAMPTZ,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.affiliate_referrals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own referrals" ON public.affiliate_referrals
  FOR SELECT USING (auth.uid() = affiliate_user_id);

CREATE POLICY "Admins can manage all referrals" ON public.affiliate_referrals
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── AFFILIATE PAYOUTS ────────────────────────────────
CREATE TABLE IF NOT EXISTS public.affiliate_payouts (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  affiliate_user_id UUID NOT NULL REFERENCES public.users(id),
  amount            DECIMAL(10,2) NOT NULL,
  status            TEXT DEFAULT 'pending' CHECK (status IN ('pending','approved','paid','rejected')),
  method            TEXT,
  notes             TEXT,
  processed_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.affiliate_payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own payouts" ON public.affiliate_payouts
  FOR SELECT USING (auth.uid() = affiliate_user_id);

CREATE POLICY "Users can create payout requests" ON public.affiliate_payouts
  FOR INSERT WITH CHECK (auth.uid() = affiliate_user_id);

CREATE POLICY "Admins can manage all payouts" ON public.affiliate_payouts
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── VOICEOVER PROFILES ──────────────────────────────
CREATE TABLE IF NOT EXISTS public.voiceover_profiles (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name                TEXT NOT NULL,
  language            TEXT NOT NULL,
  gender              TEXT CHECK (gender IN ('male','female','neutral')),
  style               TEXT,
  elevenlabs_voice_id TEXT,
  murf_voice_id       TEXT,
  sample_url          TEXT,
  active              BOOLEAN DEFAULT TRUE,
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.voiceover_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All authenticated users can view voiceover profiles" ON public.voiceover_profiles
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can manage voiceover profiles" ON public.voiceover_profiles
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── ANNOUNCEMENTS ───────────────────────────────────
CREATE TABLE IF NOT EXISTS public.announcements (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title       TEXT NOT NULL,
  message     TEXT NOT NULL,
  target_plan TEXT,
  active      BOOLEAN DEFAULT TRUE,
  starts_at   TIMESTAMPTZ,
  ends_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view active announcements" ON public.announcements
  FOR SELECT USING (active = TRUE AND (ends_at IS NULL OR ends_at > NOW()));

CREATE POLICY "Admins can manage announcements" ON public.announcements
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── GENERATED ASSETS LOG ────────────────────────────
CREATE TABLE IF NOT EXISTS public.generated_assets_log (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id    UUID REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id       UUID REFERENCES public.users(id) ON DELETE CASCADE,
  asset_type    TEXT,
  api_used      TEXT,
  cost_estimate DECIMAL(10,4) DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.generated_assets_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all asset logs" ON public.generated_assets_log
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ─── INDEXES ─────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON public.projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON public.projects(status);
CREATE INDEX IF NOT EXISTS idx_campaigns_project_id ON public.campaigns(project_id);
CREATE INDEX IF NOT EXISTS idx_campaigns_status ON public.campaigns(status);
CREATE INDEX IF NOT EXISTS idx_creatives_project_id ON public.creatives(project_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_project ON public.chat_messages(project_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_user ON public.chat_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_affiliate_referrals_affiliate ON public.affiliate_referrals(affiliate_user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON public.subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON public.subscriptions(status);

-- ─── FUNCTIONS ───────────────────────────────────────

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_projects_updated_at
  BEFORE UPDATE ON public.projects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── REALTIME ─────────────────────────────────────────
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.projects;
ALTER PUBLICATION supabase_realtime ADD TABLE public.campaigns;
ALTER PUBLICATION supabase_realtime ADD TABLE public.competitor_monitoring;
