// supabase/functions/chat-with-ai/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Auth
    const authHeader = req.headers.get('Authorization')!
    const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''))
    if (!user) throw new Error('Unauthorized')

    const { message, project_id, history = [] } = await req.json()

    // Load project context if project_id provided
    let projectContext = ''
    if (project_id && project_id !== 'general') {
      const { data: project } = await supabase
        .from('projects')
        .select('*, project_intelligence(*)')
        .eq('id', project_id)
        .single()

      if (project) {
        const intel = project.project_intelligence?.[0]
        projectContext = `
Current project context:
- Product: ${project.product_name || 'Unknown'}
- URL: ${project.product_url}
- Status: ${project.status} (Step ${project.current_step}/6)
- Platform: ${project.platform_selection || 'not selected'}
${project.brief_json ? `- Brief: ${JSON.stringify(project.brief_json)}` : ''}
${intel?.semrush_data ? `- SEMrush data available` : ''}
${intel?.fb_competitor_ads ? `- ${JSON.stringify(intel.fb_competitor_ads).slice(0, 300)}...` : ''}
`
      }
    }

    // Get Claude API key from system_api_keys
    const { data: claudeKeyRow } = await supabase
      .from('system_api_keys')
      .select('encrypted_key')
      .eq('service_name', 'anthropic')
      .single()

    if (!claudeKeyRow?.encrypted_key) {
      throw new Error('Claude API key not configured')
    }

    const systemPrompt = `You are JARVIS ADS, an elite AI traffic agent, creative director, and data analyst.
You specialize in Facebook Ads and Google Ads.
You help users analyze competitors, create ad strategies, generate creatives, and publish campaigns.

${projectContext}

Rules:
1. Always confirm what you understood before acting
2. Be direct, confident, and precise — like a world-class media buyer
3. Respond in the exact language the user writes in
4. When you detect an actionable request (generate image, change copy, adjust campaign), say you'll do it and describe the result
5. Proactively suggest improvements when you detect opportunities
6. Keep responses concise but data-rich when you have intelligence available
7. When citing data, mention the source (SEMrush, SimilarWeb, etc.)
8. Always end with a follow-up question or suggestion`

    // Call Claude API
    const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': claudeKeyRow.encrypted_key,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1024,
        system: systemPrompt,
        messages: [
          ...history.map((m: { role: string; content: string }) => ({
            role: m.role,
            content: m.content,
          })),
          { role: 'user', content: message },
        ],
      }),
    })

    const claudeData = await claudeRes.json()
    const responseText = claudeData.content?.[0]?.text || 'I could not process that. Please try again.'

    // Save messages to DB
    await supabase.from('chat_messages').insert([
      {
        project_id,
        user_id: user.id,
        role: 'user',
        content: message,
      },
      {
        project_id,
        user_id: user.id,
        role: 'assistant',
        content: responseText,
      },
    ])

    // Detect intent for smart actions
    const actions = detectActions(message)

    // Log usage
    await supabase.rpc('increment_api_calls', { service: 'anthropic' }).catch(() => {})

    return new Response(
      JSON.stringify({ response: responseText, actions }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

function detectActions(message: string): string[] {
  const lower = message.toLowerCase()
  const actions: string[] = []

  if (lower.includes('imagem') || lower.includes('image') || lower.includes('imagen')) {
    actions.push('generate_image')
  }
  if (lower.includes('vídeo') || lower.includes('video')) {
    actions.push('generate_video')
  }
  if (lower.includes('copy') || lower.includes('texto') || lower.includes('headline')) {
    actions.push('generate_copy')
  }
  if (lower.includes('campanha') || lower.includes('campaign') || lower.includes('orçamento') || lower.includes('budget')) {
    actions.push('update_campaign')
  }
  if (lower.includes('voz') || lower.includes('voice') || lower.includes('narração')) {
    actions.push('generate_voiceover')
  }

  return actions
}
