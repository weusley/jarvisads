// supabase/functions/jarvis-intelligence-orchestrator/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const authHeader = req.headers.get('Authorization')!
  const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''))
  if (!user) return new Response('Unauthorized', { status: 401 })

  const { project_id, product_url, product_domain } = await req.json()

  // Get all system API keys
  const { data: keys } = await supabase
    .from('system_api_keys')
    .select('service_name, encrypted_key, status')
    .eq('status', 'active')

  const keyMap: Record<string, string> = {}
  keys?.forEach(k => { keyMap[k.service_name] = k.encrypted_key })

  const results: Record<string, unknown> = {}
  const errors: Record<string, string> = {}

  // Run all intelligence APIs in parallel
  const tasks = await Promise.allSettled([

    // SimilarWeb
    keyMap.similarweb && fetch(
      `https://api.similarweb.com/v1/website/${product_domain}/total-traffic-and-engagement/visits?api_key=${keyMap.similarweb}&country=br&granularity=monthly&main_domain_only=false&format=json`
    ).then(r => r.json()).then(d => { results.similarweb = d }),

    // SEMrush domain overview
    keyMap.semrush && fetch(
      `https://api.semrush.com/?type=domain_rank&key=${keyMap.semrush}&export_columns=Dn,Rk,Or,Ot,Oc,Ad,At,Ac&domain=${product_domain}&database=br`
    ).then(r => r.text()).then(d => { results.semrush = { raw: d } }),

    // Perplexity real-time research
    keyMap.perplexity && fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${keyMap.perplexity}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama-3.1-sonar-large-128k-online',
        messages: [{
          role: 'user',
          content: `Research current advertising trends for the website ${product_url}. 
          What niche is this? What are the current best performing ad angles in this niche in Brazil (2025)?
          What are competitors doing? Return structured data in JSON format with: niche, trending_angles, competitor_insights, recommended_audience.`,
        }],
      }),
    }).then(r => r.json()).then(d => {
      results.perplexity = d.choices?.[0]?.message?.content
    }),

    // Facebook Ad Library (via Meta Marketing API)
    keyMap.meta_ads_token && fetch(
      `https://graph.facebook.com/v18.0/ads_archive?access_token=${keyMap.meta_ads_token}&ad_type=ALL&ad_reached_countries=BR&search_terms=${encodeURIComponent(product_domain)}&fields=id,ad_creative_body,ad_creative_link_caption,ad_delivery_start_time,page_name&limit=20`
    ).then(r => r.json()).then(d => { results.fb_ads = d }),
  ])

  // Store intelligence in project_intelligence table
  await supabase.from('project_intelligence').upsert({
    project_id,
    similarweb_data: results.similarweb || null,
    semrush_data: results.semrush || null,
    perplexity_insights: results.perplexity || null,
    fb_competitor_ads: results.fb_ads || null,
    last_updated_at: new Date().toISOString(),
  }, { onConflict: 'project_id' })

  // Update project status
  await supabase.from('projects')
    .update({ status: 'strategy' })
    .eq('id', project_id)

  return new Response(
    JSON.stringify({ success: true, results, errors }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
})
