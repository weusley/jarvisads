// supabase/functions/stripe-webhook/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14.0.0?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2023-10-16',
  httpClient: Stripe.createFetchHttpClient(),
})

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const signature = req.headers.get('stripe-signature')!
  const body = await req.text()

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      Deno.env.get('STRIPE_WEBHOOK_SECRET')!
    )
  } catch (err) {
    return new Response(`Webhook Error: ${err.message}`, { status: 400 })
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.CheckoutSession
        const userId = session.metadata?.user_id
        const subscriptionId = session.subscription as string

        if (!userId || !subscriptionId) break

        const subscription = await stripe.subscriptions.retrieve(subscriptionId)
        const priceId = subscription.items.data[0].price.id
        const plan = getPlanFromPriceId(priceId)

        // Update user plan
        await supabase.from('users').update({
          plan,
          stripe_customer_id: session.customer as string,
        }).eq('id', userId)

        // Create subscription record
        await supabase.from('subscriptions').upsert({
          user_id: userId,
          stripe_subscription_id: subscriptionId,
          stripe_price_id: priceId,
          plan,
          status: subscription.status,
          current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
          current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
        }, { onConflict: 'stripe_subscription_id' })

        // Enable affiliate if plan is active
        await supabase.from('users').update({
          affiliate_active: true
        }).eq('id', userId)

        // Handle affiliate commission
        const { data: user } = await supabase
          .from('users')
          .select('referred_by')
          .eq('id', userId)
          .single()

        if (user?.referred_by) {
          const planPrices: Record<string, number> = { starter: 49, pro: 149, agency: 399 }
          const commission = (planPrices[plan] || 0) * 0.30

          await supabase.from('affiliate_referrals').insert({
            affiliate_user_id: user.referred_by,
            referred_user_id: userId,
            commission_amount: commission,
            status: 'confirmed',
            stripe_charge_id: session.payment_intent as string,
          })

          await supabase.from('affiliates')
            .update({
              active_referrals: supabase.raw('active_referrals + 1'),
              total_referrals: supabase.raw('total_referrals + 1'),
              total_earned: supabase.raw(`total_earned + ${commission}`),
              pending_payout: supabase.raw(`pending_payout + ${commission}`),
            })
            .eq('user_id', user.referred_by)
        }

        break
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription
        const priceId = subscription.items.data[0].price.id
        const plan = getPlanFromPriceId(priceId)

        await supabase.from('subscriptions')
          .update({
            plan,
            status: subscription.status,
            current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
            current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
            cancel_at_period_end: subscription.cancel_at_period_end,
          })
          .eq('stripe_subscription_id', subscription.id)

        // Update user plan
        const { data: sub } = await supabase
          .from('subscriptions')
          .select('user_id')
          .eq('stripe_subscription_id', subscription.id)
          .single()

        if (sub) {
          await supabase.from('users').update({ plan }).eq('id', sub.user_id)
        }

        break
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription

        await supabase.from('subscriptions')
          .update({ status: 'canceled' })
          .eq('stripe_subscription_id', subscription.id)

        const { data: sub } = await supabase
          .from('subscriptions')
          .select('user_id')
          .eq('stripe_subscription_id', subscription.id)
          .single()

        if (sub) {
          await supabase.from('users').update({
            plan: 'starter',
            affiliate_active: false,
          }).eq('id', sub.user_id)
        }

        break
      }
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})

function getPlanFromPriceId(priceId: string): string {
  const starterIds = (Deno.env.get('STRIPE_STARTER_PRICE_ID') || '').split(',')
  const proIds = (Deno.env.get('STRIPE_PRO_PRICE_ID') || '').split(',')
  const agencyIds = (Deno.env.get('STRIPE_AGENCY_PRICE_ID') || '').split(',')

  if (starterIds.includes(priceId)) return 'starter'
  if (proIds.includes(priceId)) return 'pro'
  if (agencyIds.includes(priceId)) return 'agency'
  return 'starter'
}
