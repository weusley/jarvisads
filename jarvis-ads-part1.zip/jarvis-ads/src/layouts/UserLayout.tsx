import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  Home, Plus, FolderOpen, MessageSquare, Image, BarChart2,
  Users, Settings, Key, CreditCard, ChevronLeft, ChevronRight,
  Bell, LogOut, ChevronDown, Menu, X,
} from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { JarvisOrb, JarvisWordmark } from '@/components/JarvisOrb'
import { LanguageSwitcher } from '@/components/LanguageSwitcher'
import { JarvisChat } from '@/components/JarvisChat'
import { cn } from '@/lib/utils'

export default function UserLayout() {
  const { t } = useTranslation()
  const { profile, signOut } = useAuth()
  const navigate = useNavigate()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  const navItems = [
    { to: '/dashboard',           icon: Home,          label: t('dashboard.home'),          end: true },
    { to: '/dashboard/projects/new', icon: Plus,       label: t('dashboard.new_project') },
    { to: '/dashboard/projects',  icon: FolderOpen,    label: t('dashboard.my_projects') },
    { to: '/dashboard/chat',      icon: MessageSquare, label: t('dashboard.chat') },
    { to: '/dashboard/creatives', icon: Image,         label: t('dashboard.creatives') },
    { to: '/dashboard/campaigns', icon: BarChart2,     label: t('dashboard.campaigns') },
    { to: '/dashboard/affiliate', icon: Users,         label: t('dashboard.affiliate') },
  ]

  const bottomItems = [
    { to: '/dashboard/settings', icon: Settings, label: t('dashboard.settings') },
    { to: '/dashboard/api-keys', icon: Key,      label: t('dashboard.api_keys') },
    { to: '/dashboard/billing',  icon: CreditCard, label: t('dashboard.billing') },
  ]

  const planColors: Record<string, string> = {
    starter: 'text-white/50',
    pro:     'text-cyan-400',
    agency:  'text-amber-400',
  }

  async function handleSignOut() {
    await signOut()
    navigate('/login')
  }

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={cn(
        'flex items-center px-4 py-5 border-b border-white/[0.06]',
        collapsed ? 'justify-center' : 'justify-between'
      )}>
        {collapsed ? (
          <JarvisOrb size="sm" />
        ) : (
          <JarvisWordmark />
        )}
        <button
          onClick={() => setCollapsed(c => !c)}
          className="hidden lg:flex p-1.5 rounded-lg hover:bg-white/5 text-white/30
                     hover:text-white transition-all duration-200"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Plan badge */}
      {!collapsed && profile && (
        <div className="px-4 py-3 border-b border-white/[0.06]">
          <div className={cn(
            'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full',
            'bg-white/5 border border-white/10 text-xs font-mono uppercase tracking-wider',
            planColors[profile.plan]
          )}>
            <div className="w-1.5 h-1.5 rounded-full bg-current" />
            {profile.plan}
          </div>
        </div>
      )}

      {/* Main nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) => cn(
              'nav-item',
              isActive && 'active',
              collapsed && 'justify-center px-2'
            )}
            title={collapsed ? item.label : undefined}
          >
            <item.icon className="w-4 h-4 flex-shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* Bottom nav */}
      <div className="px-3 py-4 border-t border-white/[0.06] space-y-1">
        {bottomItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) => cn(
              'nav-item',
              isActive && 'active',
              collapsed && 'justify-center px-2'
            )}
            title={collapsed ? item.label : undefined}
          >
            <item.icon className="w-4 h-4 flex-shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}

        {/* Language switcher */}
        {!collapsed && (
          <div className="pt-2">
            <LanguageSwitcher />
          </div>
        )}
      </div>
    </div>
  )

  return (
    <div className="flex h-screen bg-black overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className={cn(
        'hidden lg:flex flex-col flex-shrink-0 border-r border-white/[0.06]',
        'bg-[#050505] transition-all duration-300 ease-in-out',
        collapsed ? 'w-16' : 'w-60'
      )}>
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      {mobileOpen && (
        <>
          <div className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
            onClick={() => setMobileOpen(false)} />
          <aside className="fixed left-0 top-0 bottom-0 z-50 w-64 flex flex-col
                            border-r border-white/[0.06] bg-[#050505] lg:hidden animate-slide-in-right">
            <div className="flex items-center justify-between px-4 py-5 border-b border-white/[0.06]">
              <JarvisWordmark />
              <button onClick={() => setMobileOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/5 text-white/40 hover:text-white transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <SidebarContent />
          </aside>
        </>
      )}

      {/* Main content */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Header */}
        <header className="flex items-center justify-between px-6 py-4
                           border-b border-white/[0.06] bg-[#050505] flex-shrink-0">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 rounded-lg hover:bg-white/5 text-white/40 hover:text-white transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            {/* Notifications */}
            <button className="relative p-2 rounded-lg hover:bg-white/5 text-white/40
                               hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-cyan-400" />
            </button>

            {/* User menu */}
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(o => !o)}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg
                           hover:bg-white/5 transition-colors"
              >
                <div className="w-7 h-7 rounded-full bg-white/10 border border-white/20
                                flex items-center justify-center">
                  <span className="font-heading font-semibold text-white text-xs">
                    {profile?.full_name?.[0]?.toUpperCase() || 'U'}
                  </span>
                </div>
                <span className="text-white/70 text-sm font-body hidden sm:block">
                  {profile?.full_name?.split(' ')[0] || 'User'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-white/30" />
              </button>

              {userMenuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} />
                  <div className="absolute right-0 mt-2 w-48 z-50 jarvis-card rounded-xl
                                  shadow-card overflow-hidden animate-fade-in">
                    <div className="px-4 py-3 border-b border-white/[0.06]">
                      <p className="text-white text-sm font-body truncate">{profile?.full_name}</p>
                      <p className="text-white/40 text-xs font-mono truncate">{profile?.email}</p>
                    </div>
                    <NavLink to="/dashboard/settings"
                      onClick={() => setUserMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 text-white/60 text-sm
                                 hover:text-white hover:bg-white/5 transition-colors">
                      <Settings className="w-4 h-4" />
                      Settings
                    </NavLink>
                    <button
                      onClick={handleSignOut}
                      className="w-full flex items-center gap-3 px-4 py-3 text-red-400/70
                                 text-sm hover:text-red-400 hover:bg-red-500/5 transition-colors">
                      <LogOut className="w-4 h-4" />
                      Sign out
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto bg-black">
          <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>

      {/* JARVIS Chat — global */}
      <JarvisChat />
    </div>
  )
}
