import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  BarChart2, Users, DollarSign, UserCheck, Cpu, Mic2,
  Activity, Settings, Globe, Megaphone, AlertTriangle,
  LogOut, Menu, X, ShieldAlert,
} from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { JarvisWordmark } from '@/components/JarvisOrb'
import { LanguageSwitcher } from '@/components/LanguageSwitcher'
import { cn } from '@/lib/utils'

export default function AdminLayout() {
  const { t } = useTranslation()
  const { profile, signOut } = useAuth()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)

  const navItems = [
    { to: '/admin',                    icon: BarChart2,    label: t('admin.overview'),           end: true },
    { to: '/admin/users',              icon: Users,        label: t('admin.users') },
    { to: '/admin/revenue',            icon: DollarSign,   label: t('admin.revenue') },
    { to: '/admin/affiliate',          icon: UserCheck,    label: t('admin.affiliate_mgmt') },
    { to: '/admin/intelligence-apis',  icon: Cpu,          label: t('admin.intelligence_apis') },
    { to: '/admin/voiceover-profiles', icon: Mic2,         label: t('admin.voiceover_profiles') },
    { to: '/admin/api-usage',          icon: Activity,     label: t('admin.api_usage') },
    { to: '/admin/platform-settings',  icon: Settings,     label: t('admin.platform_settings') },
    { to: '/admin/translations',       icon: Globe,        label: t('admin.translations') },
    { to: '/admin/announcements',      icon: Megaphone,    label: t('admin.announcements') },
    { to: '/admin/error-logs',         icon: AlertTriangle,label: t('admin.error_logs') },
  ]

  async function handleSignOut() {
    await signOut()
    navigate('/login')
  }

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-4 py-5 border-b border-red-500/20">
        <JarvisWordmark />
        <div className="mt-3 flex items-center gap-2">
          <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
          <span className="font-mono text-red-400 text-[10px] tracking-[0.2em] uppercase font-semibold">
            {t('admin.admin_mode')}
          </span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) => cn('nav-item', isActive && 'active')}
          >
            <item.icon className="w-4 h-4 flex-shrink-0" />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Bottom */}
      <div className="px-3 py-4 border-t border-white/[0.06] space-y-3">
        <div className="px-3">
          <p className="text-white/30 text-xs font-mono truncate">{profile?.email}</p>
        </div>
        <LanguageSwitcher />
        <button
          onClick={handleSignOut}
          className="nav-item w-full text-red-400/60 hover:text-red-400 hover:bg-red-500/5"
        >
          <LogOut className="w-4 h-4 flex-shrink-0" />
          <span>Sign out</span>
        </button>
      </div>
    </div>
  )

  return (
    <div className="flex h-screen bg-black overflow-hidden">
      {/* Red top border to signal admin mode */}
      <div className="fixed top-0 left-0 right-0 h-0.5 bg-red-500/60 z-50" />

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-60 flex-shrink-0
                        border-r border-red-500/10 bg-[#050505]">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      {mobileOpen && (
        <>
          <div className="fixed inset-0 z-40 bg-black/60 lg:hidden"
            onClick={() => setMobileOpen(false)} />
          <aside className="fixed left-0 top-0 bottom-0 z-50 w-64
                            border-r border-red-500/10 bg-[#050505] lg:hidden animate-slide-in-right">
            <div className="flex items-center justify-between px-4 py-5 border-b border-red-500/20">
              <JarvisWordmark />
              <button onClick={() => setMobileOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/5 text-white/40 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <SidebarContent />
          </aside>
        </>
      )}

      {/* Main */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Header */}
        <header className="flex items-center gap-4 px-6 py-4
                           border-b border-red-500/10 bg-[#050505] flex-shrink-0">
          <button
            onClick={() => setMobileOpen(true)}
            className="lg:hidden p-2 rounded-lg hover:bg-white/5 text-white/40 hover:text-white"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            <span className="font-mono text-red-400 text-xs tracking-wider uppercase">Admin Panel</span>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto bg-black">
          <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}
