import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '@/contexts/AuthContext'

interface ProtectedRouteProps {
  children: React.ReactNode
  requireAdmin?: boolean
}

export function ProtectedRoute({ children, requireAdmin = false }: ProtectedRouteProps) {
  const { user, profile, loading } = useAuth()
  const location = useLocation()

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="flex flex-col items-center gap-6">
          <JarvisLoadingOrb />
          <p className="text-white/40 font-mono text-sm tracking-widest uppercase">
            Initializing JARVIS...
          </p>
        </div>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }

  if (requireAdmin && profile?.role !== 'admin') {
    return <Navigate to="/dashboard" replace />
  }

  return <>{children}</>
}

function JarvisLoadingOrb() {
  return (
    <div className="relative w-20 h-20 flex items-center justify-center">
      <div
        className="absolute inset-0 rounded-full border border-white/10 animate-spin-slow"
        style={{ borderTopColor: 'rgba(0,245,255,0.6)' }}
      />
      <div
        className="absolute inset-2 rounded-full border border-white/5 animate-spin-reverse"
        style={{ borderBottomColor: 'rgba(255,255,255,0.3)' }}
      />
      <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse-glow" />
    </div>
  )
}
