import { useState, useRef, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { X, Send, Paperclip, Mic, Loader2 } from 'lucide-react'
import { supabase, ChatMessage } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { cn } from '@/lib/utils'

interface JarvisChatProps {
  projectId?: string
}

export function JarvisChat({ projectId }: JarvisChatProps) {
  const { t } = useTranslation()
  const { user } = useAuth()
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    if (open && projectId) loadHistory()
  }, [open, projectId])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  async function loadHistory() {
    if (!projectId) return
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('project_id', projectId)
      .order('created_at', { ascending: true })
      .limit(50)
    if (data) setMessages(data as ChatMessage[])
  }

  async function sendMessage() {
    if (!input.trim() || loading || !user) return
    const text = input.trim()
    setInput('')

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      project_id: projectId || 'general',
      user_id: user.id,
      role: 'user',
      content: text,
      attachments_json: null,
      created_at: new Date().toISOString(),
    }

    setMessages(prev => [...prev, userMsg])
    setLoading(true)

    try {
      const { data, error } = await supabase.functions.invoke('chat-with-ai', {
        body: {
          message: text,
          project_id: projectId,
          history: messages.slice(-10).map(m => ({
            role: m.role,
            content: m.content,
          })),
        },
      })

      if (error) throw error

      const assistantMsg: ChatMessage = {
        id: crypto.randomUUID(),
        project_id: projectId || 'general',
        user_id: user.id,
        role: 'assistant',
        content: data.response || 'Sorry, I could not process that.',
        attachments_json: data.actions || null,
        created_at: new Date().toISOString(),
      }

      setMessages(prev => [...prev, assistantMsg])
    } catch {
      setMessages(prev => [...prev, {
        id: crypto.randomUUID(),
        project_id: projectId || 'general',
        user_id: user.id,
        role: 'assistant',
        content: '⚠️ Connection error. Please try again.',
        attachments_json: null,
        created_at: new Date().toISOString(),
      }])
    } finally {
      setLoading(false)
      inputRef.current?.focus()
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  return (
    <>
      {/* Floating Button */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-6 right-6 z-50 group"
          aria-label="Open JARVIS chat"
        >
          <div className="relative w-14 h-14 flex items-center justify-center">
            {/* Rings */}
            <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-spin-slower"
              style={{ borderTopColor: 'rgba(0,245,255,0.7)' }} />
            <div className="absolute inset-1.5 rounded-full border border-white/10 animate-spin-reverse" />
            {/* Button core */}
            <div className="relative w-10 h-10 rounded-full bg-white flex items-center justify-center
                            shadow-glow group-hover:shadow-glow-lg transition-all duration-300
                            group-hover:scale-110">
              <span className="font-heading font-bold text-black text-sm">J</span>
            </div>
          </div>
        </button>
      )}

      {/* Chat Panel */}
      {open && (
        <div className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-2rem)] flex flex-col
                        rounded-2xl border border-white/10 bg-[#0a0a0a] shadow-card
                        animate-slide-in-right overflow-hidden"
          style={{ height: '560px' }}>

          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.08]
                          bg-white/[0.02]">
            <div className="flex items-center gap-3">
              <div className="relative w-8 h-8 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-spin-slower"
                  style={{ borderTopColor: 'rgba(0,245,255,0.6)' }} />
                <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse-glow" />
              </div>
              <div>
                <div className="font-heading font-semibold text-white text-sm">JARVIS</div>
                <div className="flex items-center gap-1.5">
                  <div className="dot-online" />
                  <span className="text-emerald-400 text-xs font-mono">{t('jarvis.online')}</span>
                </div>
              </div>
            </div>
            <button onClick={() => setOpen(false)}
              className="p-1.5 rounded-lg hover:bg-white/5 text-white/40 hover:text-white transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full gap-4 text-center px-6">
                <div className="relative w-16 h-16">
                  <div className="absolute inset-0 rounded-full border border-cyan-400/20 animate-spin-slower"
                    style={{ borderTopColor: 'rgba(0,245,255,0.5)' }} />
                  <div className="absolute inset-2 rounded-full border border-white/5 animate-spin-reverse" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse-glow" />
                  </div>
                </div>
                <div>
                  <p className="font-heading font-semibold text-white text-sm mb-1">
                    JARVIS está pronto
                  </p>
                  <p className="text-white/40 text-xs font-body leading-relaxed">
                    Pergunte sobre estratégia, criativos, concorrentes ou qualquer ajuste nas suas campanhas.
                  </p>
                </div>
              </div>
            )}

            {messages.map(msg => (
              <MessageBubble key={msg.id} message={msg} />
            ))}

            {loading && (
              <div className="flex items-start gap-3">
                <div className="w-7 h-7 rounded-full border border-cyan-400/30 flex items-center justify-center flex-shrink-0"
                  style={{ borderTopColor: 'rgba(0,245,255,0.6)' }}>
                  <div className="w-2 h-2 rounded-full bg-cyan-400" />
                </div>
                <div className="jarvis-card px-4 py-3 rounded-2xl rounded-tl-sm max-w-[85%]">
                  <div className="flex items-center gap-1.5">
                    <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                    <span className="text-white/50 text-xs font-mono">{t('jarvis.thinking')}</span>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="border-t border-white/[0.08] p-4">
            <div className="flex items-end gap-2">
              <button className="p-2 text-white/30 hover:text-white/60 transition-colors flex-shrink-0">
                <Paperclip className="w-4 h-4" />
              </button>
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={t('jarvis.placeholder')}
                rows={1}
                className="flex-1 bg-transparent text-white text-sm font-body placeholder-white/25
                           resize-none outline-none leading-relaxed max-h-32"
                style={{ minHeight: '24px' }}
              />
              <button className="p-2 text-white/30 hover:text-white/60 transition-colors flex-shrink-0">
                <Mic className="w-4 h-4" />
              </button>
              <button
                onClick={sendMessage}
                disabled={!input.trim() || loading}
                className="p-2 bg-white rounded-lg flex-shrink-0 disabled:opacity-30
                           hover:bg-white/90 transition-all duration-200 hover:scale-105
                           disabled:scale-100 disabled:cursor-not-allowed"
              >
                <Send className="w-4 h-4 text-black" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user'

  return (
    <div className={cn('flex items-start gap-3 chat-message-enter', isUser && 'flex-row-reverse')}>
      {/* Avatar */}
      {!isUser && (
        <div className="w-7 h-7 rounded-full border border-cyan-400/30 flex items-center
                        justify-center flex-shrink-0 bg-cyan-400/5"
          style={{ borderTopColor: 'rgba(0,245,255,0.6)' }}>
          <div className="w-2 h-2 rounded-full bg-cyan-400" />
        </div>
      )}

      {/* Bubble */}
      <div className={cn(
        'px-4 py-3 rounded-2xl max-w-[85%] text-sm font-body leading-relaxed',
        isUser
          ? 'bg-white text-black rounded-tr-sm'
          : 'jarvis-card text-white/85 rounded-tl-sm'
      )}>
        <p className="whitespace-pre-wrap">{message.content}</p>

        {/* Action buttons */}
        {message.attachments_json && Array.isArray(message.attachments_json) && (
          <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-white/10">
            {(message.attachments_json as string[]).map((action, i) => (
              <button key={i}
                className="px-3 py-1.5 rounded-lg border border-white/20 text-white/70
                           text-xs font-mono hover:border-white/40 hover:text-white
                           transition-all duration-150">
                {action}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
