import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { cn } from '@/lib/utils'

const LANGUAGES = [
  { code: 'pt-BR', label: 'Português', flag: '🇧🇷' },
  { code: 'en',    label: 'English',   flag: '🇺🇸' },
  { code: 'es',    label: 'Español',   flag: '🇪🇸' },
]

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { i18n } = useTranslation()
  const { user } = useAuth()
  const [open, setOpen] = useState(false)

  const current = LANGUAGES.find(l => l.code === i18n.language) || LANGUAGES[1]

  async function switchLang(code: string) {
    i18n.changeLanguage(code)
    localStorage.setItem('jarvis_language', code)
    setOpen(false)

    if (user) {
      await supabase.from('users').update({ language: code }).eq('id', user.id)
    }
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className={cn(
          'flex items-center gap-2 rounded-lg border border-white/10',
          'text-white/60 hover:text-white hover:border-white/30',
          'transition-all duration-200',
          compact ? 'px-2 py-1.5 text-sm' : 'px-3 py-2 text-sm'
        )}
      >
        <span className="text-base leading-none">{current.flag}</span>
        {!compact && (
          <span className="font-mono text-xs">{current.code.toUpperCase()}</span>
        )}
        <svg
          className={cn('w-3 h-3 transition-transform duration-200', open && 'rotate-180')}
          fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-2 w-44 z-50 jarvis-card rounded-xl shadow-card overflow-hidden animate-fade-in">
            {LANGUAGES.map(lang => (
              <button
                key={lang.code}
                onClick={() => switchLang(lang.code)}
                className={cn(
                  'w-full flex items-center gap-3 px-4 py-3 text-sm font-body',
                  'transition-colors duration-150 hover:bg-white/5',
                  lang.code === i18n.language
                    ? 'text-white bg-white/5'
                    : 'text-white/50'
                )}
              >
                <span className="text-base">{lang.flag}</span>
                <span>{lang.label}</span>
                {lang.code === i18n.language && (
                  <svg className="w-3.5 h-3.5 ml-auto text-cyan-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                )}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
