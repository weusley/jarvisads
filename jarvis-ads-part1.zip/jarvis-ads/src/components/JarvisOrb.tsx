import { cn } from '@/lib/utils'

interface JarvisOrbProps {
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
  pulse?: boolean
}

const sizes = {
  sm:  { outer: 48,  rings: [40, 32, 20], dot: 6  },
  md:  { outer: 80,  rings: [66, 54, 34], dot: 10 },
  lg:  { outer: 120, rings: [100, 82, 52], dot: 14 },
  xl:  { outer: 180, rings: [152, 124, 80], dot: 20 },
}

export function JarvisOrb({ size = 'md', className, pulse = true }: JarvisOrbProps) {
  const s = sizes[size]

  return (
    <div
      className={cn('relative flex items-center justify-center flex-shrink-0', className)}
      style={{ width: s.outer, height: s.outer }}
    >
      {/* Ring 1 - slowest */}
      <div
        className="absolute rounded-full border border-white/10 animate-spin-slower"
        style={{
          width: s.rings[0],
          height: s.rings[0],
          borderTopColor: 'rgba(0,245,255,0.5)',
          borderRightColor: 'rgba(0,245,255,0.15)',
        }}
      />
      {/* Ring 2 - medium */}
      <div
        className="absolute rounded-full border border-white/5 animate-spin-reverse"
        style={{
          width: s.rings[1],
          height: s.rings[1],
          borderBottomColor: 'rgba(255,255,255,0.25)',
          borderLeftColor: 'rgba(255,255,255,0.08)',
        }}
      />
      {/* Ring 3 - fastest */}
      <div
        className="absolute rounded-full border border-white/5 animate-spin-slow"
        style={{
          width: s.rings[2],
          height: s.rings[2],
          borderTopColor: 'rgba(0,245,255,0.3)',
        }}
      />
      {/* Core dot */}
      <div
        className={cn(
          'rounded-full bg-cyan-400 flex-shrink-0',
          pulse && 'animate-pulse-glow'
        )}
        style={{ width: s.dot, height: s.dot }}
      />
    </div>
  )
}

export function JarvisWordmark({ className }: { className?: string }) {
  return (
    <div className={cn('flex items-center gap-3', className)}>
      <JarvisOrb size="sm" />
      <div className="flex flex-col leading-none">
        <span className="font-heading font-bold text-white tracking-wider text-lg">JARVIS</span>
        <span className="font-mono text-cyan-400/80 text-[10px] tracking-[0.2em] uppercase">ADS</span>
      </div>
    </div>
  )
}
