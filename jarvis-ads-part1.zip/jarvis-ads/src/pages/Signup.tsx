import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Eye, EyeOff, Loader2, Check } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { JarvisOrb, JarvisWordmark } from '@/components/JarvisOrb'
import { LanguageSwitcher } from '@/components/LanguageSwitcher'
import { PLANS, cn } from '@/lib/utils'
import { loadStripe } from '@stripe/stripe-js'
import toast from 'react-hot-toast'

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || '')

type PlanKey = 'starter' | 'pro' | 'agency'

export default function Signup() {
  const { t } = useTranslation()
  const { signUp } = useAuth()
  const navigate = useNavigate()

  const [step, setStep] = useState<'account' | 'plan'>('account')
  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<PlanKey>('pro')
  const [loading, setLoading] = useState(false)
  const [userId, setUserId] = useState<string | null>(null)

  async function handleAccountSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (password.length < 8) { toast.error(t('errors.password_short')); return }
    if (password !== confirm) { toast.error(t('errors.passwords_no_match')); return }

    setLoading(true)
    const { error, userId: uid } = await signUp(email, password, fullName)
    setLoading(false)

    if (error) { toast.error(t('errors.generic')); return }
    if (uid) setUserId(uid)
    setStep('plan')
  }

  async function handleCheckout() {
    setLoading(true)
    try {
      const plan = PLANS[selectedPlan]
      // Call Supabase edge function to create Stripe checkout session
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-checkout-session`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            price_id: plan.stripePriceId,
            user_id: userId,
            email,
            success_url: `${window.location.origin}/dashboard?welcome=1`,
            cancel_url: `${window.location.origin}/signup`,
          }),
        }
      )
      const { sessionId, error } = await res.json()
      if (error) throw new Error(error)

      const stripe = await stripePromise
      await stripe?.redirectToCheckout({ sessionId })
    } catch {
      toast.error(t('errors.generic'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      <div className="fixed inset-0 grid-bg opacity-40 pointer-events-none" />

      {/* Top bar */}
      <div className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between
                      px-6 py-4 border-b border-white/[0.06] bg-black/80 backdrop-blur-md">
        <JarvisWordmark />
        <LanguageSwitcher />
      </div>

      <div className="flex flex-col items-center justify-start min-h-screen pt-24 pb-16 px-6">
        {/* Step indicator */}
        <div className="flex items-center gap-3 mb-10 animate-fade-in">
          {['account','plan'].map((s, i) => (
            <div key={s} className="flex items-center gap-3">
              <div className={cn(
                'w-7 h-7 rounded-full border flex items-center justify-center text-xs font-mono',
                step === s || (i === 0 && step === 'plan')
                  ? 'border-white bg-white text-black'
                  : 'border-white/20 text-white/30'
              )}>
                {i === 0 && step === 'plan' ? <Check className="w-3.5 h-3.5" /> : i + 1}
              </div>
              <span className={cn(
                'text-sm font-body hidden sm:block',
                step === s ? 'text-white' : 'text-white/30'
              )}>
                {i === 0 ? t('auth.signup_title') : t('auth.choose_plan')}
              </span>
              {i === 0 && <div className="w-8 h-px bg-white/20" />}
            </div>
          ))}
        </div>

        {step === 'account' && (
          <div className="w-full max-w-sm animate-fade-in">
            <div className="mb-8 text-center">
              <JarvisOrb size="md" className="mx-auto mb-4" />
              <h2 className="font-heading font-bold text-2xl text-white mb-2">
                {t('auth.signup_title')}
              </h2>
              <p className="text-white/40 font-body">{t('auth.signup_sub')}</p>
            </div>

            <form onSubmit={handleAccountSubmit} className="space-y-4">
              <div>
                <label className="jarvis-label">{t('auth.full_name')}</label>
                <input
                  type="text" value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="jarvis-input" placeholder="John Doe"
                  required autoComplete="name"
                />
              </div>
              <div>
                <label className="jarvis-label">{t('auth.email')}</label>
                <input
                  type="email" value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="jarvis-input" placeholder="you@example.com"
                  required autoComplete="email"
                />
              </div>
              <div>
                <label className="jarvis-label">{t('auth.password')}</label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'} value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="jarvis-input pr-12" placeholder="Min 8 characters"
                    required autoComplete="new-password"
                  />
                  <button type="button" onClick={() => setShowPass(s => !s)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60">
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="jarvis-label">{t('auth.confirm_password')}</label>
                <input
                  type="password" value={confirm}
                  onChange={e => setConfirm(e.target.value)}
                  className="jarvis-input" placeholder="••••••••"
                  required autoComplete="new-password"
                />
              </div>

              <button type="submit" disabled={loading}
                className="btn-primary w-full flex items-center justify-center gap-2 mt-6">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {t('auth.signup_btn')}
              </button>
            </form>

            <p className="mt-6 text-center text-white/30 text-sm font-body">
              {t('auth.has_account')}{' '}
              <Link to="/login" className="text-white hover:text-cyan-400 transition-colors font-medium">
                {t('auth.sign_in')}
              </Link>
            </p>
          </div>
        )}

        {step === 'plan' && (
          <div className="w-full max-w-4xl animate-fade-in">
            <div className="text-center mb-10">
              <h2 className="font-heading font-bold text-2xl text-white mb-2">
                {t('auth.choose_plan')}
              </h2>
              <p className="text-white/40 font-body">
                Start your free trial. Cancel anytime.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
              {(Object.entries(PLANS) as [PlanKey, typeof PLANS.starter][]).map(([key, plan]) => (
                <button
                  key={key}
                  onClick={() => setSelectedPlan(key)}
                  className={cn(
                    'relative jarvis-card p-6 text-left transition-all duration-200',
                    selectedPlan === key
                      ? 'border-white/40 bg-white/[0.06] scale-[1.02]'
                      : 'hover:border-white/20 hover:bg-white/[0.03]'
                  )}
                >
                  {selectedPlan === key && (
                    <div className="absolute top-4 right-4 w-5 h-5 rounded-full bg-white
                                    flex items-center justify-center">
                      <Check className="w-3 h-3 text-black" />
                    </div>
                  )}
                  {key === 'pro' && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <span className="bg-white text-black text-xs font-heading font-bold
                                       px-3 py-1 rounded-full">
                        {t('pricing.popular')}
                      </span>
                    </div>
                  )}
                  <h3 className="font-heading font-bold text-white text-lg mb-1">{plan.name}</h3>
                  <div className="flex items-baseline gap-1 mb-4">
                    <span className="font-heading font-bold text-3xl text-white">${plan.price}</span>
                    <span className="text-white/30 text-sm">{t('pricing.mo')}</span>
                  </div>
                  <ul className="space-y-2">
                    {plan.features.slice(0, 4).map((f, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-white/40 flex-shrink-0 mt-0.5" />
                        <span className="text-white/50 text-xs font-body">{f}</span>
                      </li>
                    ))}
                  </ul>
                </button>
              ))}
            </div>

            <div className="flex justify-center">
              <button
                onClick={handleCheckout}
                disabled={loading}
                className="btn-primary flex items-center gap-2 px-10 py-4 text-base"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
                Continue with {PLANS[selectedPlan].name} — ${PLANS[selectedPlan].price}/mo
              </button>
            </div>
            <p className="text-center text-white/20 text-xs font-mono mt-4">
              Secured by Stripe · Cancel anytime
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
