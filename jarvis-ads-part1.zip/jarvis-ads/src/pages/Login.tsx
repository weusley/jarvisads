import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Eye, EyeOff, Loader2 } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { JarvisOrb, JarvisWordmark } from '@/components/JarvisOrb'
import { LanguageSwitcher } from '@/components/LanguageSwitcher'
import toast from 'react-hot-toast'

export default function Login() {
  const { t } = useTranslation()
  const { signIn } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const from = (location.state as { from?: Location })?.from?.pathname || '/dashboard'

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email || !password) return

    setLoading(true)
    const { error } = await signIn(email, password)
    setLoading(false)

    if (error) {
      toast.error(t('errors.generic'))
      return
    }

    navigate(from, { replace: true })
  }

  return (
    <div className="min-h-screen bg-black grid lg:grid-cols-2 relative overflow-hidden">
      {/* Grid bg */}
      <div className="fixed inset-0 grid-bg opacity-40 pointer-events-none" />

      {/* Left panel */}
      <div className="hidden lg:flex flex-col items-center justify-center p-12
                      border-r border-white/[0.06] relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-[400px] h-[400px] rounded-full bg-cyan-400/[0.02] blur-3xl" />
        </div>
        <div className="relative z-10 flex flex-col items-center gap-8 text-center">
          <JarvisOrb size="xl" />
          <div>
            <h1 className="font-heading font-bold text-4xl text-white mb-3 text-glow-white">
              JARVIS ADS
            </h1>
            <p className="font-body text-white/40 text-lg max-w-sm leading-relaxed">
              Your AI Traffic Agent. Built for the Future.
            </p>
          </div>
          <div className="flex flex-col gap-2 text-left w-full max-w-xs">
            {[
              'Competitor intelligence in seconds',
              'AI-powered creative generation',
              'Auto-publish to Facebook & Google',
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 flex-shrink-0" />
                <span className="text-white/40 text-sm font-body">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div className="flex flex-col items-center justify-center p-8 relative">
        {/* Top bar */}
        <div className="absolute top-6 left-6 lg:hidden">
          <JarvisWordmark />
        </div>
        <div className="absolute top-6 right-6">
          <LanguageSwitcher />
        </div>

        <div className="w-full max-w-sm animate-fade-in">
          <div className="mb-8">
            <h2 className="font-heading font-bold text-2xl text-white mb-2">
              {t('auth.login_title')}
            </h2>
            <p className="text-white/40 font-body">{t('auth.login_sub')}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="jarvis-label">{t('auth.email')}</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="jarvis-input"
                placeholder="you@example.com"
                required
                autoComplete="email"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="jarvis-label mb-0">{t('auth.password')}</label>
                <Link to="/forgot-password"
                  className="text-white/30 hover:text-white text-xs font-body transition-colors">
                  {t('auth.forgot')}
                </Link>
              </div>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="jarvis-input pr-12"
                  placeholder="••••••••"
                  required
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(s => !s)}
                  className="absolute right-4 top-1/2 -translate-y-1/2
                             text-white/30 hover:text-white/60 transition-colors"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full flex items-center justify-center gap-2 mt-6"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : t('auth.login_btn')}
            </button>
          </form>

          <p className="mt-6 text-center text-white/30 text-sm font-body">
            {t('auth.no_account')}{' '}
            <Link to="/signup"
              className="text-white hover:text-cyan-400 transition-colors font-medium">
              {t('auth.create')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
