import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Plus, ArrowRight, Facebook, Chrome, TrendingUp, Zap } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, Project } from '@/lib/supabase'
import { cn, formatCurrency } from '@/lib/utils'

const STATUS_LABELS: Record<string, string> = {
  draft: 'Draft', analyzing: 'Analyzing', strategy: 'Strategy',
  creating: 'Creating', review: 'Review', publishing: 'Publishing', live: 'Live',
}

const STATUS_COLORS: Record<string, string> = {
  draft: 'badge-neutral', analyzing: 'badge-cyan', strategy: 'badge-cyan',
  creating: 'badge-warning', review: 'badge-warning', publishing: 'badge-warning', live: 'badge-success',
}

export default function DashboardHome() {
  const { t } = useTranslation()
  const { profile } = useAuth()
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadProjects() }, [])

  async function loadProjects() {
    const { data } = await supabase
      .from('projects')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5)
    setProjects(data || [])
    setLoading(false)
  }

  const hour = new Date().getHours()
  const greeting = hour < 12 ? t('dashboard.welcome') :
                   hour < 18 ? 'Good afternoon' : 'Good evening'

  const stats = [
    {
      label: t('dashboard.active_projects'),
      value: projects.filter(p => p.status !== 'draft').length,
      icon: Zap,
      color: 'text-cyan-400',
    },
    {
      label: t('dashboard.campaigns_running'),
      value: 0,
      icon: TrendingUp,
      color: 'text-emerald-400',
    },
    {
      label: 'Facebook Ads',
      value: '--',
      icon: Facebook,
      color: 'text-blue-400',
    },
    {
      label: 'Google Ads',
      value: '--',
      icon: Chrome,
      color: 'text-red-400',
    },
  ]

  return (
    <div className="space-y-8">
      {/* Welcome */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-heading font-bold text-2xl text-white">
            {greeting}, {profile?.full_name?.split(' ')[0] || 'there'}.
          </h1>
          <p className="text-white/40 font-body mt-1">{t('dashboard.ready')}</p>
        </div>
        <Link to="/dashboard/projects/new" className="btn-primary flex items-center gap-2 self-start">
          <Plus className="w-4 h-4" />
          {t('dashboard.new_project_cta')}
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="stat-card group">
            <div className="flex items-center justify-between mb-3">
              <span className="stat-label">{stat.label}</span>
              <stat.icon className={cn('w-4 h-4', stat.color)} />
            </div>
            <div className="stat-value">{stat.value}</div>
          </div>
        ))}
      </div>

      {/* Platform status */}
      <div className="jarvis-card p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-white">Platform Connections</h2>
          <Link to="/dashboard/api-keys"
            className="text-white/30 hover:text-white text-xs font-mono transition-colors flex items-center gap-1">
            Configure <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <PlatformCard
            name="Facebook / Instagram Ads"
            icon="📘"
            connected={false}
            href="/dashboard/api-keys"
          />
          <PlatformCard
            name="Google Ads"
            icon="🔴"
            connected={false}
            href="/dashboard/api-keys"
          />
        </div>
      </div>

      {/* Recent projects */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="section-title">{t('dashboard.recent_projects')}</h2>
          <Link to="/dashboard/projects"
            className="text-white/30 hover:text-white text-xs font-mono transition-colors">
            {t('common.view_all')} →
          </Link>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => (
              <div key={i} className="h-16 skeleton rounded-xl" />
            ))}
          </div>
        ) : projects.length === 0 ? (
          <div className="jarvis-card p-12 text-center">
            <div className="text-4xl mb-4">🚀</div>
            <p className="text-white/40 font-body mb-6">{t('dashboard.no_projects')}</p>
            <Link to="/dashboard/projects/new" className="btn-primary inline-flex items-center gap-2">
              <Plus className="w-4 h-4" />
              {t('dashboard.new_project_cta')}
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {projects.map(project => (
              <Link
                key={project.id}
                to={`/dashboard/projects/${project.id}`}
                className="jarvis-card-hover flex items-center justify-between p-4"
              >
                <div className="flex items-center gap-4 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10
                                  flex items-center justify-center flex-shrink-0">
                    <span className="text-white/50 text-xs font-mono">
                      {project.current_step}/6
                    </span>
                  </div>
                  <div className="min-w-0">
                    <p className="font-heading font-semibold text-white text-sm truncate">
                      {project.product_name || project.product_url}
                    </p>
                    <p className="text-white/30 text-xs font-mono mt-0.5 truncate">
                      {project.product_url}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className={STATUS_COLORS[project.status] || 'badge-neutral'}>
                    {STATUS_LABELS[project.status] || project.status}
                  </span>
                  <ArrowRight className="w-4 h-4 text-white/20" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* JARVIS tip */}
      <div className="jarvis-card p-5 border-cyan-400/10">
        <div className="flex items-start gap-4">
          <div className="w-8 h-8 rounded-full border border-cyan-400/30 flex items-center justify-center
                          flex-shrink-0 bg-cyan-400/5">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          </div>
          <div>
            <p className="text-cyan-400 text-xs font-mono mb-1">{t('dashboard.ai_tip')}</p>
            <p className="text-white/60 text-sm font-body leading-relaxed">
              Start by pasting your product URL and let JARVIS run a full competitive analysis.
              The more context you give, the better the creative strategy will be.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function PlatformCard({
  name, icon, connected, href
}: { name: string; icon: string; connected: boolean; href: string }) {
  return (
    <Link to={href}
      className="flex items-center justify-between p-4 rounded-xl border transition-all duration-200
                 border-white/[0.08] hover:border-white/20 hover:bg-white/[0.02]">
      <div className="flex items-center gap-3">
        <span className="text-xl">{icon}</span>
        <span className="text-white/70 text-sm font-body">{name}</span>
      </div>
      <span className={connected ? 'badge-success' : 'badge-error'}>
        <span className={cn('w-1.5 h-1.5 rounded-full', connected ? 'bg-emerald-400' : 'bg-red-400')} />
        {connected ? 'Connected' : 'Not connected'}
      </span>
    </Link>
  )
}
