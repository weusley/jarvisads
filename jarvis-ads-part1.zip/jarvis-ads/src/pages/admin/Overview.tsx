import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Users, DollarSign, TrendingDown, Activity, CheckCircle, XCircle } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { formatCurrency, cn } from '@/lib/utils'

interface AdminStats {
  totalUsers: number
  activeSubscribers: number
  mrr: number
  churnRate: number
}

const SYSTEM_APIS = [
  { name: 'Claude (Anthropic)', key: 'anthropic' },
  { name: 'SEMrush', key: 'semrush' },
  { name: 'SimilarWeb', key: 'similarweb' },
  { name: 'SpyFu', key: 'spyfu' },
  { name: 'Perplexity', key: 'perplexity' },
  { name: 'ElevenLabs', key: 'elevenlabs' },
  { name: 'Leonardo.ai', key: 'leonardo' },
  { name: 'OpenAI', key: 'openai' },
  { name: 'Luma AI', key: 'luma' },
  { name: 'Remove.bg', key: 'removebg' },
]

export default function AdminOverview() {
  const { t } = useTranslation()
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0, activeSubscribers: 0, mrr: 0, churnRate: 0,
  })
  const [apiStatuses, setApiStatuses] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadStats()
    loadApiStatuses()
  }, [])

  async function loadStats() {
    const { count: totalUsers } = await supabase
      .from('users')
      .select('*', { count: 'exact', head: true })

    const { count: activeSubscribers } = await supabase
      .from('subscriptions')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'active')

    setStats({
      totalUsers: totalUsers || 0,
      activeSubscribers: activeSubscribers || 0,
      mrr: 0, // Calculated from Stripe
      churnRate: 0,
    })
    setLoading(false)
  }

  async function loadApiStatuses() {
    const { data } = await supabase
      .from('system_api_keys')
      .select('service_name, status')

    const statuses: Record<string, boolean> = {}
    data?.forEach(row => {
      statuses[row.service_name] = row.status === 'active'
    })
    setApiStatuses(statuses)
  }

  const statsCards = [
    {
      label: t('admin.total_users'),
      value: stats.totalUsers.toLocaleString(),
      icon: Users,
      color: 'text-white',
    },
    {
      label: t('admin.active_subs'),
      value: stats.activeSubscribers.toLocaleString(),
      icon: Activity,
      color: 'text-emerald-400',
    },
    {
      label: t('admin.mrr'),
      value: formatCurrency(stats.mrr),
      icon: DollarSign,
      color: 'text-cyan-400',
    },
    {
      label: t('admin.churn'),
      value: `${stats.churnRate.toFixed(1)}%`,
      icon: TrendingDown,
      color: 'text-red-400',
    },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h1 className="section-title">{t('admin.overview')}</h1>
        <p className="section-subtitle">Platform health and performance at a glance</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statsCards.map((card, i) => (
          <div key={i} className="stat-card">
            <div className="flex items-center justify-between mb-3">
              <span className="stat-label">{card.label}</span>
              <card.icon className={cn('w-4 h-4', card.color)} />
            </div>
            {loading ? (
              <div className="h-8 w-20 skeleton rounded" />
            ) : (
              <div className="stat-value">{card.value}</div>
            )}
          </div>
        ))}
      </div>

      {/* System API Health */}
      <div className="jarvis-card p-6">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="font-heading font-semibold text-white">Intelligence APIs Health</h2>
            <p className="text-white/30 text-sm font-body mt-0.5">
              System-level API connections
            </p>
          </div>
          <a href="/admin/intelligence-apis"
            className="text-white/30 hover:text-white text-xs font-mono transition-colors">
            Manage →
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {SYSTEM_APIS.map(api => {
            const active = apiStatuses[api.key]
            return (
              <div key={api.key}
                className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-white/[0.06]">
                <span className="text-white/60 text-sm font-body">{api.name}</span>
                <span className={active ? 'badge-success' : 'badge-error'}>
                  {active
                    ? <><CheckCircle className="w-3 h-3" /> Active</>
                    : <><XCircle className="w-3 h-3" /> Not set</>
                  }
                </span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Plan distribution */}
      <div className="jarvis-card p-6">
        <h2 className="font-heading font-semibold text-white mb-5">Subscribers by Plan</h2>
        <div className="space-y-4">
          {[
            { plan: 'Starter', price: 49, count: 0, color: 'bg-white/20' },
            { plan: 'Pro',     price: 149, count: 0, color: 'bg-cyan-400/60' },
            { plan: 'Agency',  price: 399, count: 0, color: 'bg-amber-400/60' },
          ].map(row => (
            <div key={row.plan}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className={cn('w-2 h-2 rounded-full', row.color)} />
                  <span className="text-white/70 text-sm font-body">{row.plan}</span>
                  <span className="text-white/30 text-xs font-mono">${row.price}/mo</span>
                </div>
                <span className="text-white/50 text-sm font-mono">{row.count}</span>
              </div>
              <div className="progress-bar">
                <div
                  className={cn('progress-fill', row.color)}
                  style={{ width: stats.activeSubscribers > 0
                    ? `${(row.count / stats.activeSubscribers) * 100}%`
                    : '0%'
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
