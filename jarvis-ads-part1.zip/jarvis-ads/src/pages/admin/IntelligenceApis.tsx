import { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { Eye, EyeOff, Save, TestTube2, CheckCircle, XCircle, Loader2, AlertTriangle } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

const API_DEFINITIONS = [
  {
    category: 'AI Models',
    apis: [
      { key: 'anthropic',   name: 'Anthropic (Claude)',    desc: 'Core AI agent, copy generation, strategy' },
      { key: 'openai',      name: 'OpenAI (DALL-E 3 + Whisper + GPT-4o)', desc: 'Image generation, video transcription, vision analysis' },
      { key: 'perplexity',  name: 'Perplexity',           desc: 'Real-time niche trend research' },
    ],
  },
  {
    category: 'Research & Intelligence',
    apis: [
      { key: 'semrush',     name: 'SEMrush',              desc: 'Domain traffic, paid keywords, competitor spend estimates' },
      { key: 'similarweb',  name: 'SimilarWeb',           desc: 'Website traffic sources, audience demographics' },
      { key: 'spyfu',       name: 'SpyFu',                desc: 'Competitor ad history, profitable keyword research' },
    ],
  },
  {
    category: 'Creative Generation — Images',
    apis: [
      { key: 'leonardo',    name: 'Leonardo.ai',          desc: 'Ad-optimized creative image generation' },
      { key: 'stability',   name: 'Stability AI (SDXL)',  desc: 'Bulk image generation, style transfer' },
      { key: 'removebg',    name: 'Remove.bg',            desc: 'Automatic background removal (runs silently in pipeline)' },
      { key: 'bannerbear',  name: 'Bannerbear',           desc: 'Auto-generate all ad size variations from approved creative' },
    ],
  },
  {
    category: 'Creative Generation — Video & Audio',
    apis: [
      { key: 'elevenlabs',  name: 'ElevenLabs',           desc: 'Ultra-realistic voiceover in PT-BR/EN/ES' },
      { key: 'luma',        name: 'Luma AI (Dream Machine)', desc: 'Cinematic video generation from images' },
      { key: 'runway',      name: 'RunwayML',             desc: 'Video generation alternative' },
      { key: 'heygen',      name: 'HeyGen',               desc: 'AI avatar video with voiceover' },
      { key: 'murf',        name: 'Murf AI',              desc: 'Voiceover fallback (Starter plan)' },
    ],
  },
]

interface ApiKey {
  service_name: string
  encrypted_key: string
  status: 'active' | 'inactive' | 'error'
  calls_this_month: number
  last_tested_at: string | null
}

export default function IntelligenceApis() {
  const { t } = useTranslation()
  const [apiKeys, setApiKeys] = useState<Record<string, ApiKey>>({})
  const [keyInputs, setKeyInputs] = useState<Record<string, string>>({})
  const [showKey, setShowKey] = useState<Record<string, boolean>>({})
  const [saving, setSaving] = useState<Record<string, boolean>>({})
  const [testing, setTesting] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadKeys() }, [])

  async function loadKeys() {
    const { data } = await supabase.from('system_api_keys').select('*')
    const map: Record<string, ApiKey> = {}
    data?.forEach(k => { map[k.service_name] = k })
    setApiKeys(map)
    setLoading(false)
  }

  async function saveKey(serviceKey: string) {
    const value = keyInputs[serviceKey]?.trim()
    if (!value) return

    setSaving(s => ({ ...s, [serviceKey]: true }))
    try {
      const existing = apiKeys[serviceKey]
      if (existing) {
        await supabase.from('system_api_keys')
          .update({ encrypted_key: value, status: 'inactive', last_tested_at: null })
          .eq('service_name', serviceKey)
      } else {
        await supabase.from('system_api_keys')
          .insert({ service_name: serviceKey, encrypted_key: value, status: 'inactive' })
      }
      toast.success(`${serviceKey} key saved`)
      setKeyInputs(k => ({ ...k, [serviceKey]: '' }))
      loadKeys()
    } catch {
      toast.error('Failed to save key')
    } finally {
      setSaving(s => ({ ...s, [serviceKey]: false }))
    }
  }

  async function testConnection(serviceKey: string) {
    setTesting(t => ({ ...t, [serviceKey]: true }))
    try {
      const { data } = await supabase.functions.invoke('test-api-connection', {
        body: { service: serviceKey },
      })
      if (data?.success) {
        await supabase.from('system_api_keys')
          .update({ status: 'active', last_tested_at: new Date().toISOString() })
          .eq('service_name', serviceKey)
        toast.success(`${serviceKey} connection OK ✅`)
      } else {
        await supabase.from('system_api_keys')
          .update({ status: 'error' })
          .eq('service_name', serviceKey)
        toast.error(`${serviceKey} connection failed`)
      }
      loadKeys()
    } catch {
      toast.error('Test failed')
    } finally {
      setTesting(t => ({ ...t, [serviceKey]: false }))
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[1,2,3,4].map(i => <div key={i} className="h-32 skeleton rounded-xl" />)}
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="section-title">{t('admin.intelligence_apis')}</h1>
        <p className="section-subtitle">
          These API keys are system-level only. Users never see or configure them.
        </p>
      </div>

      <div className="jarvis-card p-4 border-amber-500/20">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-amber-400 text-sm font-heading font-semibold">Security Notice</p>
            <p className="text-white/50 text-sm font-body mt-1">
              All keys are AES-256 encrypted at rest and only accessible via server-side edge functions.
              They are never returned to the frontend.
            </p>
          </div>
        </div>
      </div>

      {API_DEFINITIONS.map(category => (
        <div key={category.category}>
          <h2 className="font-heading font-semibold text-white/60 text-xs uppercase tracking-widest mb-4">
            {category.category}
          </h2>
          <div className="space-y-3">
            {category.apis.map(api => {
              const existing = apiKeys[api.key]
              const isActive = existing?.status === 'active'
              const hasKey = !!existing

              return (
                <div key={api.key} className="jarvis-card p-5">
                  <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="font-heading font-semibold text-white">{api.name}</h3>
                        <span className={isActive ? 'badge-success' : hasKey ? 'badge-error' : 'badge-neutral'}>
                          {isActive
                            ? <><CheckCircle className="w-3 h-3" /> Active</>
                            : hasKey
                              ? <><XCircle className="w-3 h-3" /> Error</>
                              : 'Not configured'
                          }
                        </span>
                      </div>
                      <p className="text-white/40 text-sm font-body">{api.desc}</p>
                      {existing?.calls_this_month > 0 && (
                        <p className="text-white/20 text-xs font-mono mt-1">
                          {existing.calls_this_month.toLocaleString()} calls this month
                        </p>
                      )}
                    </div>

                    {/* Key input + actions */}
                    <div className="flex items-center gap-2 w-full lg:w-auto lg:min-w-[380px]">
                      <div className="relative flex-1">
                        <input
                          type={showKey[api.key] ? 'text' : 'password'}
                          value={keyInputs[api.key] || ''}
                          onChange={e => setKeyInputs(k => ({ ...k, [api.key]: e.target.value }))}
                          placeholder={hasKey ? '••••••••••••••••' : 'Paste API key...'}
                          className="jarvis-input pr-10 text-sm font-mono"
                        />
                        <button
                          onClick={() => setShowKey(s => ({ ...s, [api.key]: !s[api.key] }))}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60"
                        >
                          {showKey[api.key] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>

                      <button
                        onClick={() => saveKey(api.key)}
                        disabled={!keyInputs[api.key] || saving[api.key]}
                        className={cn(
                          'flex-shrink-0 p-2.5 rounded-lg border transition-all duration-200',
                          'border-white/20 hover:border-white/40 text-white/50 hover:text-white',
                          'disabled:opacity-30 disabled:cursor-not-allowed'
                        )}
                        title="Save"
                      >
                        {saving[api.key]
                          ? <Loader2 className="w-4 h-4 animate-spin" />
                          : <Save className="w-4 h-4" />
                        }
                      </button>

                      {hasKey && (
                        <button
                          onClick={() => testConnection(api.key)}
                          disabled={testing[api.key]}
                          className={cn(
                            'flex-shrink-0 p-2.5 rounded-lg border transition-all duration-200',
                            'border-cyan-400/20 hover:border-cyan-400/50 text-cyan-400/60 hover:text-cyan-400',
                            'disabled:opacity-30 disabled:cursor-not-allowed'
                          )}
                          title="Test connection"
                        >
                          {testing[api.key]
                            ? <Loader2 className="w-4 h-4 animate-spin" />
                            : <TestTube2 className="w-4 h-4" />
                          }
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      ))}
    </div>
  )
}
