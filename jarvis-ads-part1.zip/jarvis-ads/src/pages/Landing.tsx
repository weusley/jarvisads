import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  Search, Brain, Wand2, Bot, Megaphone, BarChart2,
  Check, ChevronDown, ArrowRight, Zap,
} from 'lucide-react'
import { JarvisOrb, JarvisWordmark } from '@/components/JarvisOrb'
import { LanguageSwitcher } from '@/components/LanguageSwitcher'
import { PLANS, cn } from '@/lib/utils'

const TYPEWRITER_LINES = [
  { key: 'hero.line1' },
  { key: 'hero.line2' },
]

export default function Landing() {
  const { t } = useTranslation()
  const [annual, setAnnual] = useState(false)
  const [displayText, setDisplayText] = useState('')
  const [lineIdx, setLineIdx] = useState(0)
  const [charIdx, setCharIdx] = useState(0)
  const [deleting, setDeleting] = useState(false)

  // Typewriter effect
  useEffect(() => {
    const line = t(TYPEWRITER_LINES[lineIdx].key)
    let timer: ReturnType<typeof setTimeout>

    if (!deleting && charIdx < line.length) {
      timer = setTimeout(() => {
        setDisplayText(line.slice(0, charIdx + 1))
        setCharIdx(c => c + 1)
      }, 55)
    } else if (!deleting && charIdx === line.length) {
      timer = setTimeout(() => setDeleting(true), 2200)
    } else if (deleting && charIdx > 0) {
      timer = setTimeout(() => {
        setDisplayText(line.slice(0, charIdx - 1))
        setCharIdx(c => c - 1)
      }, 28)
    } else if (deleting && charIdx === 0) {
      setDeleting(false)
      setLineIdx(i => (i + 1) % TYPEWRITER_LINES.length)
    }

    return () => clearTimeout(timer)
  }, [charIdx, deleting, lineIdx, t])

  const features = [
    { icon: Search,    titleKey: 'features.f1_title', descKey: 'features.f1_desc' },
    { icon: Brain,     titleKey: 'features.f2_title', descKey: 'features.f2_desc' },
    { icon: Wand2,     titleKey: 'features.f3_title', descKey: 'features.f3_desc' },
    { icon: Bot,       titleKey: 'features.f4_title', descKey: 'features.f4_desc' },
    { icon: Megaphone, titleKey: 'features.f5_title', descKey: 'features.f5_desc' },
    { icon: BarChart2, titleKey: 'features.f6_title', descKey: 'features.f6_desc' },
  ]

  const steps = [
    { n: '01', key: 'how.step1' },
    { n: '02', key: 'how.step2' },
    { n: '03', key: 'how.step3' },
    { n: '04', key: 'how.step4' },
    { n: '05', key: 'how.step5' },
    { n: '06', key: 'how.step6' },
  ]

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      {/* Grid background */}
      <div className="fixed inset-0 grid-bg opacity-60 pointer-events-none" />

      {/* ── NAV ── */}
      <nav className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between
                      px-6 py-4 border-b border-white/[0.06] bg-black/80 backdrop-blur-md">
        <JarvisWordmark />
        <div className="hidden md:flex items-center gap-8">
          {['nav.features','nav.pricing','nav.affiliate'].map(k => (
            <a key={k} href={`#${k.split('.')[1]}`}
              className="text-white/50 hover:text-white text-sm font-body transition-colors">
              {t(k)}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <LanguageSwitcher compact />
          <Link to="/login" className="btn-ghost text-sm hidden sm:block">{t('nav.login')}</Link>
          <Link to="/signup" className="btn-primary text-sm py-2 px-4">{t('nav.start')}</Link>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex flex-col items-center justify-center
                          px-6 pt-24 pb-20 text-center scanline-overlay overflow-hidden">
        {/* Glow blob */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
                        w-[600px] h-[600px] rounded-full
                        bg-cyan-400/[0.03] blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center gap-8 animate-fade-in">
          <JarvisOrb size="xl" className="animate-float" />

          <div className="space-y-2">
            <h1 className="font-heading font-bold text-4xl sm:text-5xl lg:text-6xl
                           text-white leading-tight tracking-tight">
              <span className="typewriter-cursor">{displayText}</span>
            </h1>
          </div>

          <p className="font-body text-white/50 text-lg max-w-xl leading-relaxed">
            {t('hero.sub')}
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/signup"
              className="btn-primary flex items-center gap-2 text-base px-8 py-3.5">
              <Zap className="w-4 h-4" />
              {t('hero.cta_start')}
            </Link>
            <button className="btn-secondary flex items-center gap-2 text-base px-8 py-3.5">
              {t('hero.cta_demo')}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-4">
            {['Powered by Claude AI', 'Meta Ads API', 'Google Ads API', 'Stripe Secured'].map(b => (
              <div key={b}
                className="px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.03]
                           text-white/40 text-xs font-mono">
                {b}
              </div>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 flex flex-col items-center gap-2 text-white/20">
          <span className="text-xs font-mono">scroll</span>
          <ChevronDown className="w-4 h-4 animate-bounce" />
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" className="relative py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-white mb-4">
              {t('features.title')}
            </h2>
            <p className="text-white/40 font-body text-lg">{t('features.sub')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f, i) => (
              <div key={i} className="jarvis-card-hover p-6 group">
                <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10
                                flex items-center justify-center mb-4
                                group-hover:border-cyan-400/30 transition-colors duration-300">
                  <f.icon className="w-5 h-5 text-white/60 group-hover:text-cyan-400
                                     transition-colors duration-300" />
                </div>
                <h3 className="font-heading font-semibold text-white mb-2">{t(f.titleKey)}</h3>
                <p className="font-body text-white/40 text-sm leading-relaxed">{t(f.descKey)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section id="how" className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-white mb-4">
              {t('how.title')}
            </h2>
            <p className="text-white/40 font-body text-lg">{t('how.sub')}</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {steps.map((step, i) => (
              <div key={i} className="flex flex-col items-center text-center gap-3">
                <div className="w-12 h-12 rounded-full border border-white/10 bg-white/[0.03]
                                flex items-center justify-center relative">
                  <span className="font-mono text-cyan-400 text-sm font-semibold">{step.n}</span>
                  {i < steps.length - 1 && (
                    <div className="absolute left-full top-1/2 -translate-y-1/2 w-4 h-px
                                    bg-white/10 hidden lg:block" />
                  )}
                </div>
                <p className="text-white/50 text-xs font-body leading-snug">{t(step.key)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING ── */}
      <section id="pricing" className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-white mb-4">
              {t('pricing.title')}
            </h2>
            <p className="text-white/40 font-body text-lg mb-8">{t('pricing.sub')}</p>

            {/* Toggle */}
            <div className="inline-flex items-center gap-4 p-1.5 rounded-xl border border-white/10 bg-white/[0.03]">
              <button
                onClick={() => setAnnual(false)}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-heading font-medium transition-all',
                  !annual ? 'bg-white text-black' : 'text-white/40 hover:text-white'
                )}
              >
                {t('pricing.monthly')}
              </button>
              <button
                onClick={() => setAnnual(true)}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-heading font-medium transition-all flex items-center gap-2',
                  annual ? 'bg-white text-black' : 'text-white/40 hover:text-white'
                )}
              >
                {t('pricing.annual')}
                <span className={cn(
                  'text-xs px-2 py-0.5 rounded-full',
                  annual ? 'bg-black/20 text-black' : 'bg-cyan-400/10 text-cyan-400'
                )}>
                  {t('pricing.save')}
                </span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(Object.entries(PLANS) as [string, typeof PLANS.starter][]).map(([key, plan]) => (
              <PricingCard
                key={key}
                plan={plan}
                planKey={key}
                annual={annual}
                popular={key === 'pro'}
                t={t}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── AFFILIATE ── */}
      <section id="affiliate" className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-3xl mx-auto text-center">
          <div className="jarvis-card p-12 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r
                            from-transparent via-cyan-400/40 to-transparent" />
            <div className="relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full
                              border border-cyan-400/30 bg-cyan-400/5 mb-6">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                <span className="text-cyan-400 text-xs font-mono">Affiliate Program</span>
              </div>
              <h2 className="font-heading font-bold text-3xl sm:text-4xl text-white mb-4">
                {t('affiliate.title')}
              </h2>
              <p className="text-white/40 font-body text-lg mb-8">{t('affiliate.sub')}</p>
              <Link to="/signup" className="btn-primary inline-flex items-center gap-2 px-8 py-3.5">
                {t('affiliate.cta')}
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-white/[0.06] py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <JarvisWordmark />
          <div className="flex items-center gap-6">
            {['features','pricing','affiliate'].map(k => (
              <a key={k} href={`#${k}`}
                className="text-white/30 hover:text-white text-sm font-body transition-colors capitalize">
                {k}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-4">
            <LanguageSwitcher compact />
            <p className="text-white/20 text-xs font-mono">© 2025 JARVIS ADS</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function PricingCard({
  plan, planKey, annual, popular, t,
}: {
  plan: typeof PLANS.starter
  planKey: string
  annual: boolean
  popular: boolean
  t: (k: string) => string
}) {
  const price = annual ? Math.floor(plan.priceAnnual / 12) : plan.price

  return (
    <div className={cn(
      'relative jarvis-card p-6 flex flex-col transition-all duration-300',
      popular && 'border-white/20 shadow-white-glow scale-[1.02]'
    )}>
      {popular && (
        <div className="absolute -top-px left-6 right-6 h-px
                        bg-gradient-to-r from-transparent via-white/60 to-transparent" />
      )}
      {popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="bg-white text-black text-xs font-heading font-bold
                           px-3 py-1 rounded-full">
            {t('pricing.popular')}
          </span>
        </div>
      )}

      <div className="mb-6">
        <h3 className="font-heading font-bold text-white text-xl mb-1">{plan.name}</h3>
        <div className="flex items-baseline gap-1">
          <span className="font-heading font-bold text-4xl text-white">${price}</span>
          <span className="text-white/30 font-body">{t('pricing.mo')}</span>
        </div>
        {annual && (
          <p className="text-white/30 text-xs font-mono mt-1">
            ${plan.priceAnnual}/year
          </p>
        )}
      </div>

      <ul className="space-y-3 flex-1 mb-8">
        {plan.features.map((f, i) => (
          <li key={i} className="flex items-start gap-3">
            <Check className="w-4 h-4 text-white/50 flex-shrink-0 mt-0.5" />
            <span className="text-white/60 text-sm font-body">{f}</span>
          </li>
        ))}
      </ul>

      <Link to="/signup" className={cn(
        'w-full text-center py-3 rounded-lg font-heading font-semibold text-sm transition-all',
        popular
          ? 'btn-primary'
          : 'btn-secondary'
      )}>
        {t('pricing.cta')}
      </Link>
    </div>
  )
}
