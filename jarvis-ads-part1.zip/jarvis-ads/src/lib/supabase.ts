import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Check your .env file.')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
})

// ─── Types ─────────────────────────────────────────────────────────────────

export type UserRole = 'admin' | 'user'
export type PlanType = 'starter' | 'pro' | 'agency'
export type PlatformType = 'facebook' | 'google' | 'both'
export type ProjectStatus = 'draft' | 'analyzing' | 'strategy' | 'creating' | 'review' | 'publishing' | 'live'
export type CampaignStatus = 'draft' | 'active' | 'paused' | 'ended'
export type CreativeType = 'text' | 'image' | 'video' | 'voiceover'

export interface UserProfile {
  id: string
  email: string
  full_name: string
  role: UserRole
  plan: PlanType
  stripe_customer_id: string | null
  language: 'pt-BR' | 'en' | 'es'
  affiliate_code: string | null
  referred_by: string | null
  affiliate_active: boolean
  avatar_url: string | null
  created_at: string
}

export interface Subscription {
  id: string
  user_id: string
  stripe_subscription_id: string
  plan: PlanType
  status: 'active' | 'canceled' | 'past_due' | 'trialing'
  current_period_end: string
}

export interface Project {
  id: string
  user_id: string
  product_url: string
  product_name: string | null
  brief_json: Record<string, unknown> | null
  platform_selection: PlatformType | null
  status: ProjectStatus
  current_step: number
  created_at: string
}

export interface Campaign {
  id: string
  project_id: string
  platform: PlatformType
  fb_campaign_id: string | null
  google_campaign_id: string | null
  status: CampaignStatus
  budget: number
  performance_json: Record<string, unknown> | null
  published_at: string | null
}

export interface AffiliateProfile {
  user_id: string
  referral_code: string
  referral_link: string
  total_referrals: number
  active_referrals: number
  total_earned: number
  pending_payout: number
  payout_method: string | null
  joined_at: string
}

export interface ChatMessage {
  id: string
  project_id: string
  user_id: string
  role: 'user' | 'assistant'
  content: string
  attachments_json: unknown[] | null
  created_at: string
}

// ─── Helper functions ───────────────────────────────────────────────────────

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const { data: profile } = await supabase
    .from('users')
    .select('*')
    .eq('id', user.id)
    .single()

  return profile as UserProfile | null
}

export async function getSubscription(userId: string) {
  const { data } = await supabase
    .from('subscriptions')
    .select('*')
    .eq('user_id', userId)
    .eq('status', 'active')
    .single()
  return data as Subscription | null
}
