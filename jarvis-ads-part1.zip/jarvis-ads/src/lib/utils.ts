import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(value: number, currency = 'USD') {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
  }).format(value)
}

export function formatBRL(value: number) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value)
}

export function formatNumber(value: number) {
  return new Intl.NumberFormat('en-US', { notation: 'compact' }).format(value)
}

export function formatPercent(value: number) {
  return `${value.toFixed(2)}%`
}

export function truncate(str: string, max: number) {
  return str.length > max ? str.slice(0, max) + '...' : str
}

export function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

export function generateReferralCode(userId: string) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 8; i++) {
    code += chars[Math.floor(Math.random() * chars.length)]
  }
  return code
}

export const PLANS = {
  starter: {
    name: 'Starter',
    price: 49,
    priceAnnual: 490,
    stripePriceId: import.meta.env.VITE_STRIPE_STARTER_PRICE_ID || '',
    stripePriceIdAnnual: import.meta.env.VITE_STRIPE_STARTER_ANNUAL_PRICE_ID || '',
    features: [
      '10 projects/month',
      'Basic creative generation',
      'Facebook Ads publishing',
      'JARVIS AI chat',
      'Competitor research',
      'Email support',
    ],
    limits: { projects: 10 },
  },
  pro: {
    name: 'Pro',
    price: 149,
    priceAnnual: 1490,
    stripePriceId: import.meta.env.VITE_STRIPE_PRO_PRICE_ID || '',
    stripePriceIdAnnual: import.meta.env.VITE_STRIPE_PRO_ANNUAL_PRICE_ID || '',
    features: [
      'Unlimited projects',
      'Video + image generation',
      'Facebook + Google Ads',
      'Priority AI processing',
      'Advanced competitor intel',
      'Affiliate program access',
      'Priority support',
    ],
    limits: { projects: -1 },
  },
  agency: {
    name: 'Agency',
    price: 399,
    priceAnnual: 3990,
    stripePriceId: import.meta.env.VITE_STRIPE_AGENCY_PRICE_ID || '',
    stripePriceIdAnnual: import.meta.env.VITE_STRIPE_AGENCY_ANNUAL_PRICE_ID || '',
    features: [
      'Everything in Pro',
      'Multi-client management',
      'White-label options',
      'Team seats (5 users)',
      'Custom AI voice profiles',
      'Dedicated account manager',
      'SLA support',
    ],
    limits: { projects: -1 },
  },
}
