import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from '@/contexts/AuthContext'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import './i18n'

// Layouts
import UserLayout from '@/layouts/UserLayout'
import AdminLayout from '@/layouts/AdminLayout'

// Public pages
import Landing from '@/pages/Landing'
import Login from '@/pages/Login'
import Signup from '@/pages/Signup'

// Dashboard pages
import DashboardHome from '@/pages/dashboard/Home'

// Admin pages
import AdminOverview from '@/pages/admin/Overview'
import IntelligenceApis from '@/pages/admin/IntelligenceApis'

// Lazy placeholders for pages built in next parts
import { lazy, Suspense } from 'react'

const PageSkeleton = () => (
  <div className="space-y-6">
    <div className="h-8 w-48 skeleton rounded-lg" />
    <div className="h-4 w-72 skeleton rounded" />
    <div className="grid grid-cols-4 gap-4">
      {[1,2,3,4].map(i => <div key={i} className="h-24 skeleton rounded-xl" />)}
    </div>
    <div className="h-64 skeleton rounded-xl" />
  </div>
)

const withSuspense = (Component: React.ComponentType) => (
  <Suspense fallback={<PageSkeleton />}>
    <Component />
  </Suspense>
)

// Dashboard lazy pages
const Projects = lazy(() => import('@/pages/dashboard/Projects').catch(() => ({ default: PlaceholderPage('My Projects') })))
const NewProject = lazy(() => import('@/pages/dashboard/NewProject').catch(() => ({ default: PlaceholderPage('New Project') })))
const ProjectDetail = lazy(() => import('@/pages/dashboard/ProjectDetail').catch(() => ({ default: PlaceholderPage('Project') })))
const Campaigns = lazy(() => import('@/pages/dashboard/Campaigns').catch(() => ({ default: PlaceholderPage('Campaigns') })))
const Creatives = lazy(() => import('@/pages/dashboard/Creatives').catch(() => ({ default: PlaceholderPage('Creatives Library') })))
const Affiliate = lazy(() => import('@/pages/dashboard/Affiliate').catch(() => ({ default: PlaceholderPage('Affiliate Program') })))
const Chat = lazy(() => import('@/pages/dashboard/Chat').catch(() => ({ default: PlaceholderPage('JARVIS Chat') })))
const Settings = lazy(() => import('@/pages/dashboard/Settings').catch(() => ({ default: PlaceholderPage('Settings') })))
const ApiKeys = lazy(() => import('@/pages/dashboard/ApiKeys').catch(() => ({ default: PlaceholderPage('API Keys') })))
const Billing = lazy(() => import('@/pages/dashboard/Billing').catch(() => ({ default: PlaceholderPage('Billing') })))

// Admin lazy pages
const AdminUsers = lazy(() => import('@/pages/admin/Users').catch(() => ({ default: PlaceholderPage('Users') })))
const AdminRevenue = lazy(() => import('@/pages/admin/Revenue').catch(() => ({ default: PlaceholderPage('Revenue') })))
const AdminAffiliate = lazy(() => import('@/pages/admin/AffiliateManagement').catch(() => ({ default: PlaceholderPage('Affiliate Management') })))
const AdminVoiceover = lazy(() => import('@/pages/admin/VoiceoverProfiles').catch(() => ({ default: PlaceholderPage('Voiceover Profiles') })))
const AdminApiUsage = lazy(() => import('@/pages/admin/ApiUsage').catch(() => ({ default: PlaceholderPage('API Usage') })))
const AdminSettings = lazy(() => import('@/pages/admin/PlatformSettings').catch(() => ({ default: PlaceholderPage('Platform Settings') })))
const AdminTranslations = lazy(() => import('@/pages/admin/Translations').catch(() => ({ default: PlaceholderPage('Translations') })))
const AdminAnnouncements = lazy(() => import('@/pages/admin/Announcements').catch(() => ({ default: PlaceholderPage('Announcements') })))
const AdminErrorLogs = lazy(() => import('@/pages/admin/ErrorLogs').catch(() => ({ default: PlaceholderPage('Error Logs') })))

function PlaceholderPage(title: string) {
  return function Page() {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
        <div className="text-4xl">🔧</div>
        <h1 className="font-heading font-bold text-white text-2xl">{title}</h1>
        <p className="text-white/40 font-body">This page is being built. Check back soon.</p>
      </div>
    )
  }
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          {/* Public */}
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />

          {/* User Dashboard */}
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <UserLayout />
            </ProtectedRoute>
          }>
            <Route index element={<DashboardHome />} />
            <Route path="projects" element={withSuspense(Projects)} />
            <Route path="projects/new" element={withSuspense(NewProject)} />
            <Route path="projects/:id" element={withSuspense(ProjectDetail)} />
            <Route path="campaigns" element={withSuspense(Campaigns)} />
            <Route path="creatives" element={withSuspense(Creatives)} />
            <Route path="affiliate" element={withSuspense(Affiliate)} />
            <Route path="chat" element={withSuspense(Chat)} />
            <Route path="settings" element={withSuspense(Settings)} />
            <Route path="api-keys" element={withSuspense(ApiKeys)} />
            <Route path="billing" element={withSuspense(Billing)} />
          </Route>

          {/* Admin Panel */}
          <Route path="/admin" element={
            <ProtectedRoute requireAdmin>
              <AdminLayout />
            </ProtectedRoute>
          }>
            <Route index element={<AdminOverview />} />
            <Route path="users" element={withSuspense(AdminUsers)} />
            <Route path="revenue" element={withSuspense(AdminRevenue)} />
            <Route path="affiliate" element={withSuspense(AdminAffiliate)} />
            <Route path="intelligence-apis" element={<IntelligenceApis />} />
            <Route path="voiceover-profiles" element={withSuspense(AdminVoiceover)} />
            <Route path="api-usage" element={withSuspense(AdminApiUsage)} />
            <Route path="platform-settings" element={withSuspense(AdminSettings)} />
            <Route path="translations" element={withSuspense(AdminTranslations)} />
            <Route path="announcements" element={withSuspense(AdminAnnouncements)} />
            <Route path="error-logs" element={withSuspense(AdminErrorLogs)} />
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#111',
              color: '#fff',
              border: '1px solid rgba(255,255,255,0.1)',
              fontFamily: '"DM Sans", sans-serif',
              fontSize: '14px',
            },
            success: {
              iconTheme: { primary: '#00f5ff', secondary: '#000' },
            },
            error: {
              iconTheme: { primary: '#ef4444', secondary: '#000' },
            },
          }}
        />
      </AuthProvider>
    </BrowserRouter>
  )
}
