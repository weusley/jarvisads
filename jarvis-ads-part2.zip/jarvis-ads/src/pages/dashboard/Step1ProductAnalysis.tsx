import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Check, Edit2, Loader2, RefreshCw, ChevronDown, ChevronUp } from 'lucide-react'
import { supabase, Project } from '@/lib/supabase'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

interface ProductBrief {
  product_name: string
  category: string
  niche: string
  sub_niche: string
  target_audience: string
  age_range: string
  gender: string
  price_point: string
  offer_type: string
  main_usps: string[]
  tone_of_voice: string
  market_size: string
  growth_trend: string
  site_quality_notes: string
}

interface Step1Props {
  project: Project
  onComplete: () => void
}

export default function Step1ProductAnalysis({ project, onComplete }: Step1Props) {
  const { t } = useTranslation()
  const brief = project.brief_json as ProductBrief | null
  const [editing, setEditing] = useState<string | null>(null)
  const [editValues, setEditValues] = useState<Partial<ProductBrief>>({})
  const [reanalyzing, setReanalyzing] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    product: true, audience: true, market: false,
  })

  async function reanalyze() {
    setReanalyzing(true)
    try {
      const domain = new URL(project.product_url).hostname.replace('www.', '')
      await supabase.functions.invoke('jarvis-intelligence-orchestrator', {
        body: {
          project_id: project.id,
          product_url: project.product_url,
          product_domain: domain,
        },
      })
      toast.success('Re-analysis started. Refresh in a moment.')
    } catch {
      toast.error('Failed to re-analyze')
    } finally {
      setReanalyzing(false)
    }
  }

  async function saveEdit(field: keyof ProductBrief) {
    if (!editValues[field]) { setEditing(null); return }
    await supabase.from('projects').update({
      brief_json: { ...brief, [field]: editValues[field] },
    }).eq('id', project.id)
    toast.success('Updated')
    setEditing(null)
    window.location.reload()
  }

  async function confirmAndContinue() {
    setConfirming(true)
    await supabase.from('projects').update({
      status: 'strategy',
      current_step: 2,
    }).eq('id', project.id)
    setConfirming(false)
    onComplete()
  }

  if (!brief) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="relative w-16 h-16">
          <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-spin-slower"
            style={{ borderTopColor: 'rgba(0,245,255,0.6)' }} />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse" />
          </div>
        </div>
        <p className="text-white/50 font-body">JARVIS is analyzing your product...</p>
        <p className="text-white/20 text-xs font-mono">This usually takes 30-60 seconds</p>
      </div>
    )
  }

  const Section = ({ title, sectionKey, children }: {
    title: string; sectionKey: string; children: React.ReactNode
  }) => (
    <div className="jarvis-card overflow-hidden">
      <button
        onClick={() => setExpandedSections(s => ({ ...s, [sectionKey]: !s[sectionKey] }))}
        className="w-full flex items-center justify-between px-5 py-4
                   hover:bg-white/[0.02] transition-colors"
      >
        <span className="font-heading font-semibold text-white text-sm">{title}</span>
        {expandedSections[sectionKey]
          ? <ChevronUp className="w-4 h-4 text-white/30" />
          : <ChevronDown className="w-4 h-4 text-white/30" />
        }
      </button>
      {expandedSections[sectionKey] && (
        <div className="px-5 pb-5 border-t border-white/[0.06] pt-4">
          {children}
        </div>
      )}
    </div>
  )

  const Field = ({ label, field, value, multiline = false }: {
    label: string; field: keyof ProductBrief; value: string; multiline?: boolean
  }) => (
    <div className="group">
      <div className="flex items-center justify-between mb-1">
        <span className="text-white/30 text-xs font-mono uppercase tracking-wider">{label}</span>
        <button
          onClick={() => { setEditing(field); setEditValues({ [field]: value }) }}
          className="opacity-0 group-hover:opacity-100 p-1 text-white/30 hover:text-white
                     transition-all duration-150"
        >
          <Edit2 className="w-3 h-3" />
        </button>
      </div>
      {editing === field ? (
        <div className="flex gap-2">
          {multiline ? (
            <textarea
              value={editValues[field] as string || ''}
              onChange={e => setEditValues(v => ({ ...v, [field]: e.target.value }))}
              className="jarvis-input text-sm flex-1 resize-none"
              rows={3}
              autoFocus
            />
          ) : (
            <input
              type="text"
              value={editValues[field] as string || ''}
              onChange={e => setEditValues(v => ({ ...v, [field]: e.target.value }))}
              className="jarvis-input text-sm flex-1"
              autoFocus
            />
          )}
          <div className="flex flex-col gap-1">
            <button onClick={() => saveEdit(field)}
              className="p-2 bg-white rounded-lg text-black hover:bg-white/90">
              <Check className="w-3.5 h-3.5" />
            </button>
            <button onClick={() => setEditing(null)}
              className="p-2 border border-white/20 rounded-lg text-white/50 hover:text-white">
              ✕
            </button>
          </div>
        </div>
      ) : (
        <p className="text-white/80 text-sm font-body">{value || '—'}</p>
      )}
    </div>
  )

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="font-heading font-bold text-xl text-white">Product Brief</h2>
          <p className="text-white/40 text-sm font-body mt-1">
            Review and refine before proceeding. Or chat with JARVIS to adjust.
          </p>
        </div>
        <button
          onClick={reanalyze}
          disabled={reanalyzing}
          className="btn-ghost flex items-center gap-2 text-sm flex-shrink-0"
        >
          {reanalyzing
            ? <Loader2 className="w-4 h-4 animate-spin" />
            : <RefreshCw className="w-4 h-4" />
          }
          Re-analyze
        </button>
      </div>

      {/* Product section */}
      <Section title="Product & Offer" sectionKey="product">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <Field label="Product Name"  field="product_name"  value={brief.product_name} />
          <Field label="Category"      field="category"      value={brief.category} />
          <Field label="Niche"         field="niche"         value={brief.niche} />
          <Field label="Sub-niche"     field="sub_niche"     value={brief.sub_niche} />
          <Field label="Price Point"   field="price_point"   value={brief.price_point} />
          <Field label="Offer Type"    field="offer_type"    value={brief.offer_type} />
          <Field label="Tone of Voice" field="tone_of_voice" value={brief.tone_of_voice} />
        </div>
        <div className="mt-5">
          <span className="text-white/30 text-xs font-mono uppercase tracking-wider">Main USPs</span>
          <div className="mt-2 flex flex-wrap gap-2">
            {(brief.main_usps || []).map((usp, i) => (
              <span key={i}
                className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10
                           text-white/70 text-sm font-body">
                {usp}
              </span>
            ))}
          </div>
        </div>
      </Section>

      {/* Audience section */}
      <Section title="Target Audience" sectionKey="audience">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <Field label="Audience Profile" field="target_audience" value={brief.target_audience} multiline />
          <Field label="Age Range"        field="age_range"       value={brief.age_range} />
          <Field label="Gender"           field="gender"          value={brief.gender} />
        </div>
      </Section>

      {/* Market section */}
      <Section title="Market Intelligence" sectionKey="market">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <Field label="Market Size"     field="market_size"         value={brief.market_size} />
          <Field label="Growth Trend"    field="growth_trend"        value={brief.growth_trend} />
          <Field label="Site Quality"    field="site_quality_notes"  value={brief.site_quality_notes} multiline />
        </div>
      </Section>

      {/* Actions */}
      <div className="flex items-center justify-between pt-2">
        <p className="text-white/30 text-sm font-body">
          You can also ask JARVIS to adjust anything via chat →
        </p>
        <button
          onClick={confirmAndContinue}
          disabled={confirming}
          className="btn-primary flex items-center gap-2"
        >
          {confirming
            ? <Loader2 className="w-4 h-4 animate-spin" />
            : <Check className="w-4 h-4" />
          }
          Confirm Brief → Step 2
        </button>
      </div>
    </div>
  )
}
