import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { ArrowRight, Globe, Loader2, Sparkles, AlertCircle } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { JarvisOrb } from '@/components/JarvisOrb'
import toast from 'react-hot-toast'

export default function NewProject() {
  const { t } = useTranslation()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  function validateUrl(input: string): string {
    let u = input.trim()
    if (!u.startsWith('http://') && !u.startsWith('https://')) {
      u = 'https://' + u
    }
    try {
      new URL(u)
      return u
    } catch {
      return ''
    }
  }

  async function handleAnalyze(e: React.FormEvent) {
    e.preventDefault()
    setError('')

    const validUrl = validateUrl(url)
    if (!validUrl) {
      setError('Please enter a valid URL (e.g. https://yourproduct.com)')
      return
    }

    setLoading(true)

    try {
      // Create project record
      const { data: project, error: projectError } = await supabase
        .from('projects')
        .insert({
          user_id: user!.id,
          product_url: validUrl,
          status: 'analyzing',
          current_step: 1,
        })
        .select()
        .single()

      if (projectError || !project) throw new Error('Failed to create project')

      // Trigger intelligence orchestrator
      const domain = new URL(validUrl).hostname.replace('www.', '')
      const { error: fnError } = await supabase.functions.invoke('jarvis-intelligence-orchestrator', {
        body: {
          project_id: project.id,
          product_url: validUrl,
          product_domain: domain,
        },
      })

      if (fnError) {
        // Still navigate — partial analysis is better than nothing
        console.warn('Orchestrator error:', fnError)
      }

      // Navigate to project detail
      navigate(`/dashboard/projects/${project.id}`)
    } catch (err) {
      toast.error('Failed to start analysis. Please try again.')
      setLoading(false)
    }
  }

  const examples = [
    'https://exemplo.com.br',
    'https://myproduct.com',
    'https://tienda.ejemplo.com',
  ]

  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center max-w-2xl mx-auto">
      {/* Hero */}
      <div className="text-center mb-12 animate-fade-in">
        <JarvisOrb size="lg" className="mx-auto mb-6" />
        <h1 className="font-heading font-bold text-3xl text-white mb-3">
          {t('workflow.step1')}
        </h1>
        <p className="text-white/40 font-body text-lg">
          Paste your product URL. JARVIS will analyze everything automatically.
        </p>
      </div>

      {/* Form */}
      <form onSubmit={handleAnalyze} className="w-full animate-fade-in">
        <div className="jarvis-card p-6 space-y-4">
          <div className="relative">
            <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30" />
            <input
              type="text"
              value={url}
              onChange={e => setUrl(e.target.value)}
              placeholder={t('workflow.url_placeholder')}
              className="jarvis-input pl-12 py-4 text-base"
              disabled={loading}
              autoFocus
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={!url.trim() || loading}
            className="btn-primary w-full flex items-center justify-center gap-3 py-4 text-base
                       disabled:opacity-30 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                {t('workflow.analyzing')}
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                {t('workflow.analyze_btn')}
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </form>

      {/* What JARVIS does */}
      {!loading && (
        <div className="mt-8 w-full animate-fade-in">
          <p className="text-white/30 text-xs font-mono text-center mb-4 uppercase tracking-widest">
            What JARVIS does automatically
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { icon: '🔍', text: 'Analyzes your website content and offer' },
              { icon: '🏆', text: 'Researches top 20 competitors in your niche' },
              { icon: '📊', text: 'Gets traffic & audience data (SimilarWeb + SEMrush)' },
              { icon: '🎯', text: 'Identifies best-performing ad angles' },
              { icon: '💡', text: 'Maps real-time trends (Perplexity)' },
              { icon: '📈', text: 'Estimates keywords & CPC (Keyword Planner)' },
            ].map((item, i) => (
              <div key={i}
                className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                <span className="text-lg">{item.icon}</span>
                <span className="text-white/50 text-sm font-body">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Loading state */}
      {loading && (
        <div className="mt-8 w-full animate-fade-in">
          <div className="jarvis-card p-6 space-y-4">
            <div className="flex items-center justify-center gap-3 mb-2">
              <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span className="text-cyan-400 text-sm font-mono">JARVIS is running full analysis...</span>
            </div>
            {[
              'Scraping website content...',
              'Querying Facebook Ad Library...',
              'Fetching SEMrush domain data...',
              'Analyzing SimilarWeb audience...',
              'Running real-time trend search...',
              'Building intelligence report...',
            ].map((step, i) => (
              <div key={i}
                className="flex items-center gap-3 animate-fade-in"
                style={{ animationDelay: `${i * 0.8}s` }}
              >
                <Loader2 className="w-3.5 h-3.5 text-white/30 animate-spin flex-shrink-0" />
                <span className="text-white/40 text-sm font-body">{step}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
