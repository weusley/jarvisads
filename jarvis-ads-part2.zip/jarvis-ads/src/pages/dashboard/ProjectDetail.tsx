import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { ChevronLeft, Check, Loader2 } from 'lucide-react'
import { supabase, Project } from '@/lib/supabase'
import { JarvisChat } from '@/components/JarvisChat'
import { cn } from '@/lib/utils'
import Step1ProductAnalysis from './Step1ProductAnalysis'
import Step2CompetitorResearch from './Step2CompetitorResearch'
import toast from 'react-hot-toast'

const STEPS = [
  { n: 1, label: 'Product',     shortLabel: '1' },
  { n: 2, label: 'Research',    shortLabel: '2' },
  { n: 3, label: 'Strategy',    shortLabel: '3' },
  { n: 4, label: 'Creatives',   shortLabel: '4' },
  { n: 5, label: 'Review',      shortLabel: '5' },
  { n: 6, label: 'Publish',     shortLabel: '6' },
]

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>()
  const { t } = useTranslation()
  const navigate = useNavigate()

  const [project, setProject] = useState<Project | null>(null)
  const [intelligence, setIntelligence] = useState<Record<string, unknown> | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentStep, setCurrentStep] = useState(1)

  useEffect(() => {
    if (id) {
      loadProject()
      // Subscribe to real-time updates
      const sub = supabase
        .channel(`project-${id}`)
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'projects',
          filter: `id=eq.${id}`,
        }, payload => {
          setProject(payload.new as Project)
          setCurrentStep((payload.new as Project).current_step)
        })
        .subscribe()
      return () => { supabase.removeChannel(sub) }
    }
  }, [id])

  async function loadProject() {
    const { data: proj } = await supabase
      .from('projects')
      .select('*')
      .eq('id', id)
      .single()

    if (!proj) { navigate('/dashboard/projects'); return }

    setProject(proj as Project)
    setCurrentStep((proj as Project).current_step)

    // Load intelligence data
    const { data: intel } = await supabase
      .from('project_intelligence')
      .select('*')
      .eq('project_id', id)
      .single()

    if (intel) setIntelligence(intel)
    setLoading(false)
  }

  function handleStepComplete() {
    loadProject()
    toast.success('Step complete! Moving to next step.')
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-4">
          <div className="relative w-12 h-12">
            <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-spin-slower"
              style={{ borderTopColor: 'rgba(0,245,255,0.6)' }} />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
            </div>
          </div>
          <p className="text-white/40 font-mono text-sm">Loading project...</p>
        </div>
      </div>
    )
  }

  if (!project) return null

  return (
    <div className="space-y-6">
      {/* Back + title */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate('/dashboard/projects')}
          className="p-2 rounded-lg hover:bg-white/5 text-white/40 hover:text-white transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="min-w-0">
          <h1 className="font-heading font-bold text-xl text-white truncate">
            {project.product_name || new URL(project.product_url).hostname}
          </h1>
          <p className="text-white/30 text-xs font-mono truncate">{project.product_url}</p>
        </div>
      </div>

      {/* Step progress wizard */}
      <div className="jarvis-card p-4">
        <div className="flex items-center justify-between">
          {STEPS.map((step, i) => {
            const done = currentStep > step.n
            const active = currentStep === step.n
            const future = currentStep < step.n

            return (
              <div key={step.n} className="flex items-center flex-1">
                {/* Step node */}
                <div className="flex flex-col items-center gap-1.5">
                  <button
                    onClick={() => done && setCurrentStep(step.n)}
                    disabled={future}
                    className={cn(
                      'w-8 h-8 rounded-full border flex items-center justify-center',
                      'transition-all duration-300 text-xs font-mono',
                      done
                        ? 'border-white bg-white text-black cursor-pointer hover:scale-110'
                        : active
                          ? 'border-cyan-400 bg-cyan-400/10 text-cyan-400'
                          : 'border-white/15 text-white/20 cursor-not-allowed'
                    )}
                  >
                    {done ? <Check className="w-3.5 h-3.5" /> : step.shortLabel}
                  </button>
                  <span className={cn(
                    'text-[10px] font-mono hidden sm:block',
                    active ? 'text-white' : done ? 'text-white/50' : 'text-white/20'
                  )}>
                    {step.label}
                  </span>
                </div>

                {/* Connector */}
                {i < STEPS.length - 1 && (
                  <div className={cn(
                    'flex-1 h-px mx-2 transition-colors duration-500',
                    done ? 'bg-white/40' : 'bg-white/10'
                  )} />
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* Step content */}
      <div className="min-h-[400px]">
        {currentStep === 1 && (
          <Step1ProductAnalysis
            project={project}
            onComplete={handleStepComplete}
          />
        )}

        {currentStep === 2 && (
          <Step2CompetitorResearch
            project={project}
            intelligence={intelligence as never}
            onComplete={handleStepComplete}
          />
        )}

        {currentStep === 3 && (
          <ComingSoonStep
            step={3}
            title="Creative Strategy"
            desc="JARVIS will generate 3 campaign concepts based on your brief and competitor research."
            items={[
              'Positioning strategy & key differentiators',
              'Target audience profile (demographics + interests)',
              '3 campaign concepts with different angles',
              'Platform selection: Facebook / Google / Both',
            ]}
          />
        )}

        {currentStep === 4 && (
          <ComingSoonStep
            step={4}
            title="Content Creation"
            desc="Generate copy, images, voiceover and video automatically."
            items={[
              'Ad copy variations (short / medium / long)',
              'Image creatives (Leonardo.ai + DALL-E 3)',
              'Video ads (HeyGen + Luma AI + RunwayML)',
              'Voiceover (ElevenLabs PT-BR/EN/ES)',
            ]}
          />
        )}

        {currentStep === 5 && (
          <ComingSoonStep
            step={5}
            title="Review & Approval"
            desc="Review all creatives side-by-side before publishing."
            items={[
              'Side-by-side copy + image + video review',
              'Inline editing for any asset',
              'Google Ads quality score check',
              'Approve individual or all at once',
            ]}
          />
        )}

        {currentStep === 6 && (
          <ComingSoonStep
            step={6}
            title="Campaign Publishing"
            desc="Publish directly to Facebook Ads and/or Google Ads."
            items={[
              'Facebook campaign configuration',
              'Google Ads configuration (Search / PMax / Display / YouTube)',
              'Budget, audience, placements setup',
              'One-click publish to both platforms',
            ]}
          />
        )}
      </div>

      {/* JARVIS Chat — project-specific */}
      <JarvisChat projectId={id} />
    </div>
  )
}

function ComingSoonStep({ step, title, desc, items }: {
  step: number; title: string; desc: string; items: string[]
}) {
  return (
    <div className="space-y-5 animate-fade-in">
      <div>
        <h2 className="font-heading font-bold text-xl text-white">Step {step}: {title}</h2>
        <p className="text-white/40 text-sm font-body mt-1">{desc}</p>
      </div>

      <div className="jarvis-card p-8 flex flex-col items-center text-center gap-6">
        <div className="relative w-16 h-16">
          <div className="absolute inset-0 rounded-full border border-white/10 animate-spin-slower"
            style={{ borderTopColor: 'rgba(255,255,255,0.3)' }} />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="font-heading font-bold text-white text-xl">0{step}</span>
          </div>
        </div>

        <div>
          <p className="font-heading font-semibold text-white text-lg mb-1">{title}</p>
          <p className="text-white/30 text-sm font-body mb-6 max-w-md">
            This step is coming in Part 3 of the code delivery.
            You can already talk to JARVIS via the chat to preview what this step will do.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-lg text-left">
          {items.map((item, i) => (
            <div key={i} className="flex items-start gap-2.5">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 flex-shrink-0 mt-1.5" />
              <span className="text-white/50 text-sm font-body">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
