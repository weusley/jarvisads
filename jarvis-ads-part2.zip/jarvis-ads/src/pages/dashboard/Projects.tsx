import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  Plus, Search, ArrowRight, Trash2, MoreVertical,
  Globe, Clock, CheckCircle2,
} from 'lucide-react'
import { supabase, Project } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  draft:      { label: 'Draft',      color: 'badge-neutral', icon: <Clock className="w-3 h-3" /> },
  analyzing:  { label: 'Analyzing', color: 'badge-cyan',    icon: <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" /> },
  strategy:   { label: 'Strategy',  color: 'badge-cyan',    icon: <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" /> },
  creating:   { label: 'Creating',  color: 'badge-warning', icon: <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" /> },
  review:     { label: 'Review',    color: 'badge-warning', icon: <div className="w-2 h-2 rounded-full bg-amber-400" /> },
  publishing: { label: 'Publishing',color: 'badge-warning', icon: <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" /> },
  live:       { label: 'Live',      color: 'badge-success', icon: <CheckCircle2 className="w-3 h-3" /> },
}

const PLATFORM_ICONS: Record<string, string> = {
  facebook: '📘',
  google: '🔴',
  both: '⚡',
}

export default function Projects() {
  const { t } = useTranslation()
  const { user } = useAuth()
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [openMenu, setOpenMenu] = useState<string | null>(null)

  useEffect(() => { loadProjects() }, [])

  async function loadProjects() {
    const { data } = await supabase
      .from('projects')
      .select('*')
      .eq('user_id', user!.id)
      .order('created_at', { ascending: false })
    setProjects(data || [])
    setLoading(false)
  }

  async function deleteProject(id: string) {
    if (!confirm('Delete this project? This cannot be undone.')) return
    await supabase.from('projects').delete().eq('id', id)
    setProjects(p => p.filter(x => x.id !== id))
    toast.success('Project deleted')
    setOpenMenu(null)
  }

  const filtered = projects.filter(p =>
    (p.product_name || p.product_url).toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="section-title">{t('dashboard.my_projects')}</h1>
          <p className="section-subtitle">{projects.length} project{projects.length !== 1 ? 's' : ''}</p>
        </div>
        <Link to="/dashboard/projects/new" className="btn-primary flex items-center gap-2 self-start">
          <Plus className="w-4 h-4" />
          {t('dashboard.new_project_cta')}
        </Link>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search projects..."
          className="jarvis-input pl-11"
        />
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-20 skeleton rounded-xl" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="jarvis-card p-16 text-center">
          <div className="text-5xl mb-4">🚀</div>
          <p className="font-heading font-semibold text-white text-lg mb-2">
            {search ? 'No projects found' : t('dashboard.no_projects')}
          </p>
          <p className="text-white/30 font-body text-sm mb-6">
            {search ? 'Try a different search term' : 'Paste a product URL and JARVIS will do the rest.'}
          </p>
          {!search && (
            <Link to="/dashboard/projects/new" className="btn-primary inline-flex items-center gap-2">
              <Plus className="w-4 h-4" />
              {t('dashboard.new_project_cta')}
            </Link>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(project => {
            const status = STATUS_CONFIG[project.status] || STATUS_CONFIG.draft
            const domain = (() => {
              try { return new URL(project.product_url).hostname }
              catch { return project.product_url }
            })()

            return (
              <div key={project.id}
                className="jarvis-card group flex items-center gap-4 p-4
                           hover:border-white/20 hover:bg-white/[0.03] transition-all duration-200">

                {/* Favicon / icon */}
                <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10
                                flex items-center justify-center flex-shrink-0">
                  <Globe className="w-4 h-4 text-white/30" />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="font-heading font-semibold text-white truncate">
                      {project.product_name || domain}
                    </p>
                    {project.platform_selection && (
                      <span className="text-sm">{PLATFORM_ICONS[project.platform_selection]}</span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <p className="text-white/30 text-xs font-mono truncate">{domain}</p>
                    <span className="text-white/20 text-xs font-mono">
                      Step {project.current_step}/6
                    </span>
                  </div>
                </div>

                {/* Step progress bar */}
                <div className="hidden sm:flex flex-col gap-1 w-24">
                  <div className="flex justify-between">
                    <span className="text-white/20 text-[10px] font-mono">Progress</span>
                    <span className="text-white/40 text-[10px] font-mono">
                      {Math.round((project.current_step / 6) * 100)}%
                    </span>
                  </div>
                  <div className="progress-bar">
                    <div
                      className="progress-fill"
                      style={{ width: `${(project.current_step / 6) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Status */}
                <span className={cn('flex-shrink-0 hidden md:inline-flex', status.color)}>
                  {status.icon}
                  {status.label}
                </span>

                {/* Date */}
                <span className="text-white/20 text-xs font-mono hidden lg:block flex-shrink-0">
                  {new Date(project.created_at).toLocaleDateString()}
                </span>

                {/* Actions */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Link
                    to={`/dashboard/projects/${project.id}`}
                    className="btn-secondary text-sm py-2 px-3 flex items-center gap-1.5"
                  >
                    Open <ArrowRight className="w-3.5 h-3.5" />
                  </Link>

                  <div className="relative">
                    <button
                      onClick={() => setOpenMenu(openMenu === project.id ? null : project.id)}
                      className="p-2 rounded-lg text-white/30 hover:text-white hover:bg-white/5 transition-colors"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {openMenu === project.id && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setOpenMenu(null)} />
                        <div className="absolute right-0 mt-1 w-40 z-50 jarvis-card rounded-xl
                                        shadow-card overflow-hidden animate-fade-in">
                          <button
                            onClick={() => deleteProject(project.id)}
                            className="w-full flex items-center gap-3 px-4 py-3 text-red-400/70
                                       text-sm hover:text-red-400 hover:bg-red-500/5 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                            Delete
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
