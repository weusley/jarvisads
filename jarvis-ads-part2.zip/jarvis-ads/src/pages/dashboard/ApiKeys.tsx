import { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import {
  Eye, EyeOff, Save, TestTube2, CheckCircle, XCircle,
  Loader2, ExternalLink, Info, Facebook, Chrome,
} from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

interface ApiKeyDef {
  key: string
  name: string
  desc: string
  placeholder: string
  docsUrl: string
  icon: React.ReactNode
  extraFields?: { key: string; label: string; placeholder: string }[]
}

const API_DEFINITIONS: ApiKeyDef[] = [
  {
    key: 'facebook_ads',
    name: 'Facebook / Instagram Ads',
    desc: 'Required to publish campaigns on Facebook and Instagram.',
    placeholder: 'EAAxxxxxxxxxxxxxxx...',
    docsUrl: 'https://developers.facebook.com/docs/marketing-api',
    icon: <span className="text-xl">📘</span>,
    extraFields: [
      { key: 'ad_account_id', label: 'Ad Account ID', placeholder: 'act_xxxxxxxxxx' },
    ],
  },
  {
    key: 'google_ads',
    name: 'Google Ads',
    desc: 'Connect via OAuth to publish Search, PMax, Display and YouTube campaigns.',
    placeholder: 'Connect via OAuth below',
    docsUrl: 'https://developers.google.com/google-ads/api',
    icon: <span className="text-xl">🔴</span>,
    extraFields: [
      { key: 'customer_id', label: 'Customer ID', placeholder: 'xxx-xxx-xxxx' },
    ],
  },
  {
    key: 'google_analytics',
    name: 'Google Analytics 4 (optional)',
    desc: 'JARVIS will use your real conversion data to optimize campaign suggestions.',
    placeholder: 'Connect via OAuth below',
    docsUrl: 'https://developers.google.com/analytics',
    icon: <span className="text-xl">📊</span>,
    extraFields: [
      { key: 'ga4_property_id', label: 'GA4 Property ID', placeholder: 'G-XXXXXXXXXX' },
    ],
  },
  {
    key: 'google_search_console',
    name: 'Google Search Console (optional)',
    desc: 'JARVIS will avoid bidding on keywords where you already rank organically.',
    placeholder: 'Connect via OAuth below',
    docsUrl: 'https://search.google.com/search-console',
    icon: <span className="text-xl">🔍</span>,
  },
]

interface StoredKey {
  service_name: string
  status: 'active' | 'inactive' | 'error'
  extra_data: Record<string, string> | null
  last_tested_at: string | null
}

export default function ApiKeys() {
  const { t } = useTranslation()
  const { user } = useAuth()

  const [storedKeys, setStoredKeys] = useState<Record<string, StoredKey>>({})
  const [keyInputs, setKeyInputs] = useState<Record<string, string>>({})
  const [extraInputs, setExtraInputs] = useState<Record<string, Record<string, string>>>({})
  const [showKey, setShowKey] = useState<Record<string, boolean>>({})
  const [saving, setSaving] = useState<Record<string, boolean>>({})
  const [testing, setTesting] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadKeys() }, [])

  async function loadKeys() {
    const { data } = await supabase
      .from('api_keys')
      .select('service_name, status, extra_data, last_tested_at')
      .eq('user_id', user!.id)

    const map: Record<string, StoredKey> = {}
    data?.forEach(k => { map[k.service_name] = k })
    setStoredKeys(map)
    setLoading(false)
  }

  async function saveKey(apiKey: ApiKeyDef) {
    const value = keyInputs[apiKey.key]?.trim()
    const extra = extraInputs[apiKey.key] || {}
    if (!value && !Object.values(extra).some(v => v)) return

    setSaving(s => ({ ...s, [apiKey.key]: true }))
    try {
      const payload = {
        user_id: user!.id,
        service_name: apiKey.key,
        encrypted_key: value || storedKeys[apiKey.key]?.extra_data?.token || '___oauth___',
        extra_data: extra,
        status: 'inactive' as const,
        last_tested_at: null,
      }

      const existing = storedKeys[apiKey.key]
      if (existing) {
        await supabase.from('api_keys')
          .update({ encrypted_key: payload.encrypted_key, extra_data: payload.extra_data, status: 'inactive' })
          .eq('user_id', user!.id)
          .eq('service_name', apiKey.key)
      } else {
        await supabase.from('api_keys').insert(payload)
      }

      toast.success(`${apiKey.name} saved`)
      setKeyInputs(k => ({ ...k, [apiKey.key]: '' }))
      loadKeys()
    } catch {
      toast.error('Failed to save. Try again.')
    } finally {
      setSaving(s => ({ ...s, [apiKey.key]: false }))
    }
  }

  async function testConnection(apiKey: ApiKeyDef) {
    setTesting(t => ({ ...t, [apiKey.key]: true }))
    try {
      const { data } = await supabase.functions.invoke('test-user-api-connection', {
        body: { service: apiKey.key },
      })
      const success = data?.success
      await supabase.from('api_keys')
        .update({
          status: success ? 'active' : 'error',
          last_tested_at: new Date().toISOString(),
        })
        .eq('user_id', user!.id)
        .eq('service_name', apiKey.key)

      if (success) {
        toast.success(`${apiKey.name} — connection OK ✅`)
      } else {
        toast.error(`${apiKey.name} — connection failed. Check your key.`)
      }
      loadKeys()
    } catch {
      toast.error('Test failed. Check your key.')
    } finally {
      setTesting(t => ({ ...t, [apiKey.key]: false }))
    }
  }

  async function connectGoogleOAuth(service: string) {
    // Redirect to Google OAuth flow via Supabase
    const { data } = await supabase.functions.invoke('google-oauth-start', {
      body: { service, redirect_url: window.location.href },
    })
    if (data?.auth_url) {
      window.location.href = data.auth_url
    } else {
      toast.error('Could not start OAuth flow. Configure Google credentials in Supabase.')
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3, 4].map(i => <div key={i} className="h-32 skeleton rounded-xl" />)}
      </div>
    )
  }

  return (
    <div className="space-y-8 max-w-3xl">
      {/* Header */}
      <div>
        <h1 className="section-title">{t('dashboard.api_keys')}</h1>
        <p className="section-subtitle">
          Connect your ad platforms. All keys are AES-256 encrypted and never exposed.
        </p>
      </div>

      {/* Info banner */}
      <div className="jarvis-card p-4 border-cyan-400/10">
        <div className="flex items-start gap-3">
          <Info className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-cyan-400 text-xs font-mono mb-1">Intelligence APIs</p>
            <p className="text-white/50 text-sm font-body">
              Research tools (SEMrush, SimilarWeb, ElevenLabs, Leonardo.ai, etc.) are
              provided by the platform — you don't need to configure them.
              Only connect your ad publishing accounts below.
            </p>
          </div>
        </div>
      </div>

      {/* API Key Cards */}
      <div className="space-y-4">
        {API_DEFINITIONS.map(api => {
          const stored = storedKeys[api.key]
          const isActive = stored?.status === 'active'
          const hasKey = !!stored
          const isOAuth = ['google_ads', 'google_analytics', 'google_search_console'].includes(api.key)

          return (
            <div key={api.key} className="jarvis-card p-6">
              {/* Top row */}
              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="flex items-center gap-3">
                  {api.icon}
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-heading font-semibold text-white">{api.name}</h3>
                      <span className={isActive ? 'badge-success' : hasKey ? 'badge-error' : 'badge-neutral'}>
                        {isActive
                          ? <><CheckCircle className="w-3 h-3" />{t('common.connected')}</>
                          : hasKey
                            ? <><XCircle className="w-3 h-3" />Error</>
                            : t('common.not_configured')
                        }
                      </span>
                    </div>
                    <p className="text-white/40 text-sm font-body mt-0.5">{api.desc}</p>
                  </div>
                </div>
                <a
                  href={api.docsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 p-1.5 text-white/20 hover:text-white/50 transition-colors"
                  title="API Docs"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>

              {/* Key input */}
              {isOAuth ? (
                <div className="space-y-3">
                  {api.extraFields?.map(field => (
                    <div key={field.key}>
                      <label className="jarvis-label">{field.label}</label>
                      <input
                        type="text"
                        value={extraInputs[api.key]?.[field.key] || stored?.extra_data?.[field.key] || ''}
                        onChange={e => setExtraInputs(prev => ({
                          ...prev,
                          [api.key]: { ...prev[api.key], [field.key]: e.target.value }
                        }))}
                        className="jarvis-input font-mono text-sm"
                        placeholder={field.placeholder}
                      />
                    </div>
                  ))}
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => connectGoogleOAuth(api.key)}
                      className="btn-primary flex items-center gap-2 text-sm py-2.5"
                    >
                      <Chrome className="w-4 h-4" />
                      {hasKey ? 'Reconnect via Google' : 'Connect via Google OAuth'}
                    </button>
                    {hasKey && (
                      <button
                        onClick={() => testConnection(api)}
                        disabled={testing[api.key]}
                        className="btn-secondary flex items-center gap-2 text-sm py-2.5"
                      >
                        {testing[api.key]
                          ? <Loader2 className="w-4 h-4 animate-spin" />
                          : <TestTube2 className="w-4 h-4" />
                        }
                        {t('common.test')}
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {/* Main key */}
                  <div>
                    <label className="jarvis-label">API Token / Access Token</label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <input
                          type={showKey[api.key] ? 'text' : 'password'}
                          value={keyInputs[api.key] || ''}
                          onChange={e => setKeyInputs(k => ({ ...k, [api.key]: e.target.value }))}
                          className="jarvis-input pr-10 font-mono text-sm"
                          placeholder={hasKey ? '••••••••••••••••' : api.placeholder}
                        />
                        <button
                          onClick={() => setShowKey(s => ({ ...s, [api.key]: !s[api.key] }))}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60"
                        >
                          {showKey[api.key] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Extra fields */}
                  {api.extraFields?.map(field => (
                    <div key={field.key}>
                      <label className="jarvis-label">{field.label}</label>
                      <input
                        type="text"
                        value={extraInputs[api.key]?.[field.key] || stored?.extra_data?.[field.key] || ''}
                        onChange={e => setExtraInputs(prev => ({
                          ...prev,
                          [api.key]: { ...prev[api.key], [field.key]: e.target.value }
                        }))}
                        className="jarvis-input font-mono text-sm"
                        placeholder={field.placeholder}
                      />
                    </div>
                  ))}

                  {/* Action buttons */}
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => saveKey(api)}
                      disabled={!keyInputs[api.key] && !Object.values(extraInputs[api.key] || {}).some(v => v)}
                      className={cn(
                        'btn-primary flex items-center gap-2 text-sm py-2.5',
                        'disabled:opacity-30 disabled:cursor-not-allowed'
                      )}
                    >
                      {saving[api.key]
                        ? <Loader2 className="w-4 h-4 animate-spin" />
                        : <Save className="w-4 h-4" />
                      }
                      {t('common.save')}
                    </button>
                    {hasKey && (
                      <button
                        onClick={() => testConnection(api)}
                        disabled={testing[api.key]}
                        className="btn-secondary flex items-center gap-2 text-sm py-2.5"
                      >
                        {testing[api.key]
                          ? <Loader2 className="w-4 h-4 animate-spin" />
                          : <TestTube2 className="w-4 h-4" />
                        }
                        {t('common.test')}
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Last tested */}
              {stored?.last_tested_at && (
                <p className="text-white/20 text-xs font-mono mt-3">
                  Last tested: {new Date(stored.last_tested_at).toLocaleString()}
                </p>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
