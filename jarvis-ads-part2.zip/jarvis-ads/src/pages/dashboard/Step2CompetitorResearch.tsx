import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import {
  TrendingUp, Globe, DollarSign, Users, ArrowRight,
  Loader2, RefreshCw, ExternalLink, BarChart2, Search,
} from 'lucide-react'
import { supabase, Project } from '@/lib/supabase'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

interface IntelligenceData {
  similarweb_data?: {
    visits: number
    bounce_rate: number
    traffic_sources: Record<string, number>
    top_countries: string[]
    audience: { female: number; age_25_34: number }
  }
  semrush_data?: {
    organic_keywords: number
    paid_keywords: number
    traffic_cost: number
    authority_score: number
    competitors: { domain: string; traffic: number; keywords: number }[]
  }
  spyfu_data?: {
    monthly_budget: number
    top_ads: { headline: string; description: string; running_days: number }[]
    top_keywords: { keyword: string; cpc: number; volume: number }[]
  }
  perplexity_insights?: string
  fb_competitor_ads?: {
    data: {
      id: string
      page_name: string
      ad_creative_body: string
      ad_delivery_start_time: string
    }[]
  }
  keyword_planner_data?: {
    keywords: { keyword: string; volume: number; cpc_low: number; cpc_high: number; competition: string }[]
  }
}

interface Step2Props {
  project: Project
  intelligence: IntelligenceData | null
  onComplete: () => void
}

export default function Step2CompetitorResearch({ project, intelligence, onComplete }: Step2Props) {
  const { t } = useTranslation()
  const [refreshing, setRefreshing] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const [activeTab, setActiveTab] = useState<'facebook' | 'google' | 'overview'>('overview')

  async function refreshIntelligence() {
    setRefreshing(true)
    try {
      const domain = new URL(project.product_url).hostname.replace('www.', '')
      await supabase.functions.invoke('jarvis-intelligence-orchestrator', {
        body: { project_id: project.id, product_url: project.product_url, product_domain: domain },
      })
      toast.success('Refreshing intelligence data...')
      setTimeout(() => window.location.reload(), 3000)
    } catch {
      toast.error('Refresh failed')
    } finally {
      setRefreshing(false)
    }
  }

  async function confirmAndContinue() {
    setConfirming(true)
    await supabase.from('projects').update({ current_step: 3, status: 'strategy' }).eq('id', project.id)
    setConfirming(false)
    onComplete()
  }

  if (!intelligence) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="relative w-16 h-16">
          <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-spin-slower"
            style={{ borderTopColor: 'rgba(0,245,255,0.6)' }} />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse" />
          </div>
        </div>
        <p className="text-white/50 font-body">JARVIS is researching your competitors...</p>
      </div>
    )
  }

  const sw = intelligence.similarweb_data
  const semr = intelligence.semrush_data
  const spyfu = intelligence.spyfu_data
  const fbAds = intelligence.fb_competitor_ads?.data || []
  const keywords = intelligence.keyword_planner_data?.keywords || []

  const tabs = [
    { key: 'overview', label: 'Niche Report' },
    { key: 'facebook', label: '📘 Facebook Ads' },
    { key: 'google',   label: '🔴 Google Ads' },
  ]

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="font-heading font-bold text-xl text-white">Competitor & Niche Research</h2>
          <p className="text-white/40 text-sm font-body mt-1">
            Intelligence gathered from SEMrush, SimilarWeb, SpyFu, Facebook Ad Library & Google
          </p>
        </div>
        <button
          onClick={refreshIntelligence}
          disabled={refreshing}
          className="btn-ghost flex items-center gap-2 text-sm flex-shrink-0"
        >
          {refreshing ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          Refresh
        </button>
      </div>

      {/* Top stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          icon={<Globe className="w-4 h-4 text-cyan-400" />}
          label="Monthly Visits"
          value={sw?.visits ? formatNumber(sw.visits) : '—'}
          source="SimilarWeb"
        />
        <StatCard
          icon={<Users className="w-4 h-4 text-emerald-400" />}
          label="Auth. Score"
          value={semr?.authority_score ? `${semr.authority_score}/100` : '—'}
          source="SEMrush"
        />
        <StatCard
          icon={<DollarSign className="w-4 h-4 text-amber-400" />}
          label="Est. Ad Spend"
          value={spyfu?.monthly_budget ? `$${Math.round(spyfu.monthly_budget / 1000)}k/mo` : '—'}
          source="SpyFu"
        />
        <StatCard
          icon={<Search className="w-4 h-4 text-white/50" />}
          label="Paid Keywords"
          value={semr?.paid_keywords ? semr.paid_keywords.toLocaleString() : '—'}
          source="SEMrush"
        />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-white/[0.03] rounded-xl border border-white/[0.06]">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as typeof activeTab)}
            className={cn(
              'flex-1 py-2.5 px-3 rounded-lg text-sm font-body transition-all duration-200',
              activeTab === tab.key
                ? 'bg-white text-black font-semibold'
                : 'text-white/40 hover:text-white'
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'overview' && (
        <div className="space-y-4 animate-fade-in">
          {/* JARVIS AI Summary */}
          {intelligence.perplexity_insights && (
            <div className="jarvis-card p-5 border-cyan-400/10">
              <div className="flex items-start gap-3">
                <div className="w-7 h-7 rounded-full border border-cyan-400/30 flex items-center
                                justify-center flex-shrink-0 bg-cyan-400/5">
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                </div>
                <div>
                  <p className="text-cyan-400 text-xs font-mono mb-2">JARVIS Real-time Analysis</p>
                  <p className="text-white/70 text-sm font-body leading-relaxed whitespace-pre-wrap">
                    {typeof intelligence.perplexity_insights === 'string'
                      ? intelligence.perplexity_insights.slice(0, 800)
                      : JSON.stringify(intelligence.perplexity_insights).slice(0, 800)
                    }
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Traffic sources */}
          {sw?.traffic_sources && (
            <div className="jarvis-card p-5">
              <h3 className="font-heading font-semibold text-white text-sm mb-4">
                Traffic Sources — Niche Average
                <span className="text-white/30 text-xs font-mono ml-2">SimilarWeb</span>
              </h3>
              <div className="space-y-3">
                {Object.entries(sw.traffic_sources).map(([source, pct]) => (
                  <div key={source}>
                    <div className="flex justify-between mb-1">
                      <span className="text-white/60 text-sm font-body capitalize">{source}</span>
                      <span className="text-white/50 text-sm font-mono">{Math.round(Number(pct))}%</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill bg-white/40" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Competitors table */}
          {semr?.competitors && semr.competitors.length > 0 && (
            <div className="jarvis-card p-5">
              <h3 className="font-heading font-semibold text-white text-sm mb-4">
                Top Competitors
                <span className="text-white/30 text-xs font-mono ml-2">SEMrush</span>
              </h3>
              <table className="jarvis-table">
                <thead>
                  <tr>
                    <th>Domain</th>
                    <th>Traffic/mo</th>
                    <th>Keywords</th>
                  </tr>
                </thead>
                <tbody>
                  {semr.competitors.slice(0, 8).map((comp, i) => (
                    <tr key={i}>
                      <td>
                        <a href={`https://${comp.domain}`} target="_blank" rel="noopener"
                          className="flex items-center gap-1.5 text-white/70 hover:text-white transition-colors">
                          {comp.domain}
                          <ExternalLink className="w-3 h-3 opacity-50" />
                        </a>
                      </td>
                      <td className="font-mono">{formatNumber(comp.traffic)}</td>
                      <td className="font-mono">{formatNumber(comp.keywords)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'facebook' && (
        <div className="space-y-4 animate-fade-in">
          {fbAds.length === 0 ? (
            <EmptyState
              icon="📘"
              title="No Facebook ads found yet"
              desc="JARVIS will search again when you refresh. Or check that your Meta API token is configured in API Keys."
            />
          ) : (
            <>
              <p className="text-white/30 text-sm font-body">
                Found <span className="text-white">{fbAds.length}</span> active competitor ads
              </p>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                {fbAds.map((ad, i) => (
                  <div key={ad.id || i} className="jarvis-card p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-6 h-6 rounded-full bg-blue-500/20 border border-blue-500/30
                                      flex items-center justify-center">
                        <span className="text-xs">f</span>
                      </div>
                      <span className="text-white/70 text-sm font-body">{ad.page_name}</span>
                      <span className="text-white/20 text-xs font-mono ml-auto">
                        {ad.ad_delivery_start_time
                          ? new Date(ad.ad_delivery_start_time).toLocaleDateString()
                          : ''}
                      </span>
                    </div>
                    <p className="text-white/60 text-sm font-body leading-relaxed line-clamp-4">
                      {ad.ad_creative_body}
                    </p>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* SpyFu top ads */}
          {spyfu?.top_ads && spyfu.top_ads.length > 0 && (
            <div className="jarvis-card p-5">
              <h3 className="font-heading font-semibold text-white text-sm mb-4">
                Best Performing Competitor Ads
                <span className="text-white/30 text-xs font-mono ml-2">SpyFu</span>
              </h3>
              <div className="space-y-3">
                {spyfu.top_ads.map((ad, i) => (
                  <div key={i} className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-white font-heading font-semibold text-sm">{ad.headline}</p>
                      <span className="badge-neutral text-[10px]">
                        {ad.running_days}d active
                      </span>
                    </div>
                    <p className="text-white/50 text-sm font-body">{ad.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'google' && (
        <div className="space-y-4 animate-fade-in">
          {keywords.length === 0 ? (
            <EmptyState
              icon="🔴"
              title="Keyword data not available"
              desc="Configure Google Ads API in your API Keys to unlock keyword intelligence."
            />
          ) : (
            <div className="jarvis-card p-5">
              <h3 className="font-heading font-semibold text-white text-sm mb-4">
                Top Keywords
                <span className="text-white/30 text-xs font-mono ml-2">Google Keyword Planner</span>
              </h3>
              <table className="jarvis-table">
                <thead>
                  <tr>
                    <th>Keyword</th>
                    <th>Volume/mo</th>
                    <th>CPC Low</th>
                    <th>CPC High</th>
                    <th>Competition</th>
                  </tr>
                </thead>
                <tbody>
                  {keywords.slice(0, 15).map((kw, i) => (
                    <tr key={i}>
                      <td className="font-mono text-xs">{kw.keyword}</td>
                      <td className="font-mono">{kw.volume.toLocaleString()}</td>
                      <td className="font-mono text-emerald-400/80">${kw.cpc_low.toFixed(2)}</td>
                      <td className="font-mono text-amber-400/80">${kw.cpc_high.toFixed(2)}</td>
                      <td>
                        <span className={cn(
                          'text-xs font-mono',
                          kw.competition === 'LOW' ? 'text-emerald-400' :
                          kw.competition === 'HIGH' ? 'text-red-400' : 'text-amber-400'
                        )}>
                          {kw.competition}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* SpyFu keywords */}
          {spyfu?.top_keywords && spyfu.top_keywords.length > 0 && (
            <div className="jarvis-card p-5">
              <h3 className="font-heading font-semibold text-white text-sm mb-4">
                Competitor Paid Keywords
                <span className="text-white/30 text-xs font-mono ml-2">SpyFu</span>
              </h3>
              <div className="flex flex-wrap gap-2">
                {spyfu.top_keywords.map((kw, i) => (
                  <div key={i}
                    className="flex items-center gap-2 px-3 py-2 rounded-lg
                               bg-white/[0.03] border border-white/[0.08]">
                    <span className="text-white/70 text-sm font-body">{kw.keyword}</span>
                    <span className="text-white/30 text-xs font-mono">${kw.cpc.toFixed(2)}</span>
                    <span className="text-white/20 text-xs font-mono">{kw.volume.toLocaleString()}/mo</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Action */}
      <div className="flex items-center justify-between pt-2">
        <p className="text-white/30 text-sm font-body">
          Ask JARVIS: "What are the best performing angles in my niche?" →
        </p>
        <button
          onClick={confirmAndContinue}
          disabled={confirming}
          className="btn-primary flex items-center gap-2"
        >
          {confirming ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
          Continue to Strategy
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  )
}

function StatCard({ icon, label, value, source }: {
  icon: React.ReactNode; label: string; value: string; source: string
}) {
  return (
    <div className="stat-card">
      <div className="flex items-center justify-between mb-2">
        {icon}
        <span className="text-white/20 text-[10px] font-mono">{source}</span>
      </div>
      <div className="stat-value text-xl">{value}</div>
      <div className="stat-label text-xs">{label}</div>
    </div>
  )
}

function EmptyState({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="jarvis-card p-12 text-center">
      <div className="text-4xl mb-3">{icon}</div>
      <p className="font-heading font-semibold text-white mb-2">{title}</p>
      <p className="text-white/30 text-sm font-body max-w-sm mx-auto">{desc}</p>
    </div>
  )
}

function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`
  return n.toString()
}
