import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  Copy, Check, QrCode, Share2, Lock, Users,
  DollarSign, TrendingUp, Clock, ExternalLink, Loader2,
} from 'lucide-react'
import { supabase, AffiliateProfile, getSubscription } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { formatCurrency, generateReferralCode, cn } from '@/lib/utils'
import toast from 'react-hot-toast'

export default function Affiliate() {
  const { t } = useTranslation()
  const { user, profile } = useAuth()
  const [hasActiveSub, setHasActiveSub] = useState<boolean | null>(null)
  const [affiliate, setAffiliate] = useState<AffiliateProfile | null>(null)
  const [referrals, setReferrals] = useState<unknown[]>([])
  const [payouts, setPayouts] = useState<unknown[]>([])
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)
  const [requestingPayout, setRequestingPayout] = useState(false)

  useEffect(() => { init() }, [])

  async function init() {
    const sub = await getSubscription(user!.id)
    const isActive = sub?.status === 'active'
    setHasActiveSub(isActive)

    if (isActive) {
      await loadAffiliateData()
    }
    setLoading(false)
  }

  async function loadAffiliateData() {
    const { data: aff } = await supabase
      .from('affiliates')
      .select('*')
      .eq('user_id', user!.id)
      .single()

    if (aff) {
      setAffiliate(aff as AffiliateProfile)
    } else {
      // Create affiliate profile
      const code = generateReferralCode(user!.id)
      const link = `${window.location.origin}/signup?ref=${code}`
      const { data: newAff } = await supabase
        .from('affiliates')
        .insert({
          user_id: user!.id,
          referral_code: code,
          referral_link: link,
          total_referrals: 0,
          active_referrals: 0,
          total_earned: 0,
          pending_payout: 0,
        })
        .select()
        .single()
      setAffiliate(newAff as AffiliateProfile)

      // Update user affiliate_code
      await supabase.from('users').update({ affiliate_code: code }).eq('id', user!.id)
    }

    const { data: refs } = await supabase
      .from('affiliate_referrals')
      .select('*')
      .eq('affiliate_user_id', user!.id)
      .order('created_at', { ascending: false })
      .limit(20)
    setReferrals(refs || [])

    const { data: pouts } = await supabase
      .from('affiliate_payouts')
      .select('*')
      .eq('affiliate_user_id', user!.id)
      .order('created_at', { ascending: false })
      .limit(10)
    setPayouts(pouts || [])
  }

  async function copyLink() {
    if (!affiliate?.referral_link) return
    await navigator.clipboard.writeText(affiliate.referral_link)
    setCopied(true)
    toast.success('Link copied!')
    setTimeout(() => setCopied(false), 2000)
  }

  async function requestPayout() {
    if (!affiliate || affiliate.pending_payout < 50) {
      toast.error('Minimum payout is $50')
      return
    }
    setRequestingPayout(true)
    const { error } = await supabase.from('affiliate_payouts').insert({
      affiliate_user_id: user!.id,
      amount: affiliate.pending_payout,
      status: 'pending',
    })
    setRequestingPayout(false)
    if (error) { toast.error('Request failed. Try again.'); return }
    toast.success('Payout requested! Processing within 5 business days.')
    loadAffiliateData()
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => <div key={i} className="h-32 skeleton rounded-xl" />)}
      </div>
    )
  }

  // ── Subscription gate ─────────────────────────────────────────────────────
  if (!hasActiveSub) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center gap-6 max-w-md mx-auto">
        <div className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center">
          <Lock className="w-7 h-7 text-white/30" />
        </div>
        <div>
          <h1 className="font-heading font-bold text-2xl text-white mb-3">
            {t('affiliate.title')}
          </h1>
          <p className="text-white/40 font-body leading-relaxed mb-1">
            {t('affiliate.locked')}
          </p>
          <p className="text-white/30 text-sm font-body">
            Earn 30% recurring commission on every referral. Available for all active subscribers.
          </p>
        </div>
        <Link to="/dashboard/billing" className="btn-primary flex items-center gap-2">
          {t('affiliate.upgrade')}
        </Link>
        <div className="grid grid-cols-3 gap-4 w-full mt-4">
          {[
            { label: 'Commission', value: '30%' },
            { label: 'Cookie', value: '60 days' },
            { label: 'Payout', value: 'Monthly' },
          ].map((stat, i) => (
            <div key={i} className="stat-card text-center">
              <div className="font-heading font-bold text-white text-xl">{stat.value}</div>
              <div className="text-white/30 text-xs font-mono mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // ── Affiliate Dashboard ────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      <div>
        <h1 className="section-title">{t('dashboard.affiliate')}</h1>
        <p className="section-subtitle">Earn 30% recurring commission on every referral</p>
      </div>

      {/* Referral link */}
      <div className="jarvis-card p-6">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-emerald-400 text-xs font-mono uppercase tracking-wider">Your Affiliate Link</span>
        </div>
        <p className="text-white/30 text-sm font-body mb-4">
          Share this link. You earn 30% of every payment from referred users — forever.
        </p>

        <div className="flex gap-2 mb-4">
          <div className="flex-1 jarvis-input font-mono text-sm text-white/60 flex items-center">
            {affiliate?.referral_link || '...'}
          </div>
          <button onClick={copyLink}
            className="btn-primary flex items-center gap-2 text-sm px-4 flex-shrink-0">
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied!' : 'Copy'}
          </button>
        </div>

        {/* Share shortcuts */}
        <div className="flex flex-wrap gap-2">
          {[
            {
              label: 'WhatsApp', color: 'text-green-400 border-green-400/20',
              href: `https://wa.me/?text=${encodeURIComponent(`🚀 JARVIS ADS — AI traffic agent. Try it: ${affiliate?.referral_link}`)}`,
            },
            {
              label: 'Email', color: 'text-blue-400 border-blue-400/20',
              href: `mailto:?subject=Check out JARVIS ADS&body=${encodeURIComponent(`Hey! I've been using JARVIS ADS to automate my ad campaigns. Try it here: ${affiliate?.referral_link}`)}`,
            },
            {
              label: 'LinkedIn', color: 'text-blue-300 border-blue-300/20',
              href: `https://linkedin.com/shareArticle?url=${encodeURIComponent(affiliate?.referral_link || '')}`,
            },
            {
              label: 'Twitter/X', color: 'text-white/60 border-white/20',
              href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(`AI traffic agent that automates Facebook & Google Ads 🚀 ${affiliate?.referral_link}`)}`,
            },
          ].map(share => (
            <a key={share.label}
              href={share.href}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-body',
                'transition-colors hover:bg-white/5',
                share.color
              )}
            >
              <Share2 className="w-3 h-3" />
              {share.label}
            </a>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Referrals', value: affiliate?.total_referrals || 0, icon: <Users className="w-4 h-4 text-white/40" /> },
          { label: 'Active Paying', value: affiliate?.active_referrals || 0, icon: <TrendingUp className="w-4 h-4 text-emerald-400" /> },
          { label: 'Total Earned', value: formatCurrency(affiliate?.total_earned || 0), icon: <DollarSign className="w-4 h-4 text-cyan-400" /> },
          { label: 'Pending Payout', value: formatCurrency(affiliate?.pending_payout || 0), icon: <Clock className="w-4 h-4 text-amber-400" /> },
        ].map((stat, i) => (
          <div key={i} className="stat-card">
            <div className="flex items-center justify-between mb-2">{stat.icon}</div>
            <div className="stat-value">{stat.value}</div>
            <div className="stat-label">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Payout request */}
      <div className="jarvis-card p-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h2 className="font-heading font-semibold text-white mb-1">Payout</h2>
            <p className="text-white/40 text-sm font-body">
              Minimum: $50 · Paid monthly via Stripe or PIX
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-white font-heading font-bold text-xl">
                {formatCurrency(affiliate?.pending_payout || 0)}
              </p>
              <p className="text-white/30 text-xs font-mono">available</p>
            </div>
            <button
              onClick={requestPayout}
              disabled={!affiliate || affiliate.pending_payout < 50 || requestingPayout}
              className="btn-primary flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed"
            >
              {requestingPayout ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              Request Payout
            </button>
          </div>
        </div>
      </div>

      {/* Referrals table */}
      {referrals.length > 0 && (
        <div className="jarvis-card p-5">
          <h2 className="font-heading font-semibold text-white mb-4">Referral History</h2>
          <table className="jarvis-table">
            <thead>
              <tr>
                <th>User</th>
                <th>Plan</th>
                <th>Commission</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {(referrals as Record<string, string>[]).map((ref, i) => (
                <tr key={i}>
                  <td className="font-mono text-xs text-white/40">
                    {ref.referred_user_id?.slice(0, 8)}...
                  </td>
                  <td className="capitalize">{ref.plan || '—'}</td>
                  <td className="font-mono text-emerald-400">
                    {ref.commission_amount ? formatCurrency(Number(ref.commission_amount)) : '—'}
                  </td>
                  <td>
                    <span className={cn(
                      ref.status === 'paid' ? 'badge-success' :
                      ref.status === 'confirmed' ? 'badge-cyan' :
                      'badge-neutral'
                    )}>
                      {ref.status}
                    </span>
                  </td>
                  <td className="font-mono text-xs text-white/30">
                    {ref.created_at ? new Date(ref.created_at).toLocaleDateString() : ''}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Marketing materials */}
      <div className="jarvis-card p-6">
        <h2 className="font-heading font-semibold text-white mb-4">Marketing Materials</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { label: 'Banner Pack (3 sizes)', icon: '🖼️', desc: '300x250, 728x90, 320x50' },
            { label: 'Social Media Copy', icon: '✍️', desc: 'PT-BR / EN / ES ready' },
            { label: 'Email Template', icon: '📧', desc: 'Ready to send to your list' },
          ].map((mat, i) => (
            <button key={i}
              className="jarvis-card-hover p-4 text-left flex items-start gap-3">
              <span className="text-2xl">{mat.icon}</span>
              <div>
                <p className="text-white/80 text-sm font-heading font-semibold">{mat.label}</p>
                <p className="text-white/30 text-xs font-body mt-0.5">{mat.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
