// supabase/functions/generate-voiceover/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const authHeader = req.headers.get('Authorization')!
  const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''))
  if (!user) return new Response('Unauthorized', { status: 401 })

  const { project_id, script, voice_id, language } = await req.json()

  // Get voiceover API keys
  const { data: keys } = await supabase
    .from('system_api_keys')
    .select('service_name, encrypted_key')
    .in('service_name', ['elevenlabs', 'murf'])
    .eq('status', 'active')

  const keyMap: Record<string, string> = {}
  keys?.forEach(k => { keyMap[k.service_name] = k.encrypted_key })

  // Get voice profile
  const { data: voiceProfile } = await supabase
    .from('voiceover_profiles')
    .select('*')
    .eq('id', voice_id)
    .single()

  let audioUrl = ''
  let apiUsed = ''

  // Try ElevenLabs first
  if (keyMap.elevenlabs && voiceProfile?.elevenlabs_voice_id) {
    try {
      const elRes = await fetch(
        `https://api.elevenlabs.io/v1/text-to-speech/${voiceProfile.elevenlabs_voice_id}`,
        {
          method: 'POST',
          headers: {
            'xi-api-key': keyMap.elevenlabs,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            text: script,
            model_id: 'eleven_multilingual_v2',
            voice_settings: {
              stability: 0.5,
              similarity_boost: 0.75,
              style: 0.3,
              use_speaker_boost: true,
            },
          }),
        }
      )

      if (elRes.ok) {
        const audioBlob = await elRes.blob()
        const arrayBuffer = await audioBlob.arrayBuffer()
        const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)))
        audioUrl = `data:audio/mpeg;base64,${base64}`
        apiUsed = 'elevenlabs'
      }
    } catch (e) {
      console.error('ElevenLabs failed:', e)
    }
  }

  // Fallback to Murf AI
  if (!audioUrl && keyMap.murf && voiceProfile?.murf_voice_id) {
    try {
      const murfRes = await fetch('https://api.murf.ai/v1/speech/generate', {
        method: 'POST',
        headers: {
          'api-key': keyMap.murf,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          voiceId: voiceProfile.murf_voice_id,
          text: script,
          format: 'MP3',
          sampleRate: 48000,
        }),
      })
      const murfData = await murfRes.json()
      if (murfData.audioFile) {
        audioUrl = murfData.audioFile
        apiUsed = 'murf'
      }
    } catch (e) {
      console.error('Murf failed:', e)
    }
  }

  if (!audioUrl) {
    return new Response(
      JSON.stringify({ error: 'No voiceover API configured or generation failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  // Save to creatives
  await supabase.from('creatives').insert({
    project_id,
    type: 'voiceover',
    platform: 'general',
    content_url: audioUrl,
    metadata: { script, voice_id, language, voice_name: voiceProfile?.name },
    api_used: apiUsed,
    approved: false,
  })

  await supabase.rpc('increment_api_calls', { service: apiUsed }).catch(() => {})

  return new Response(
    JSON.stringify({ success: true, audio_url: audioUrl, api_used: apiUsed }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
})
