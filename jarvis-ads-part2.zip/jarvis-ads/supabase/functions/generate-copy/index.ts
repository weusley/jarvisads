// supabase/functions/generate-copy/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const authHeader = req.headers.get('Authorization')!
  const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''))
  if (!user) return new Response('Unauthorized', { status: 401 })

  const { project_id, strategy, platform, copy_type } = await req.json()

  const { data: claudeKey } = await supabase
    .from('system_api_keys')
    .select('encrypted_key')
    .eq('service_name', 'anthropic')
    .eq('status', 'active')
    .single()

  if (!claudeKey) throw new Error('Claude API not configured')

  const { data: project } = await supabase
    .from('projects')
    .select('*, project_intelligence(*)')
    .eq('id', project_id)
    .single()

  const brief = project?.brief_json || {}
  const intel = project?.project_intelligence?.[0]

  const isGoogle = platform === 'google'

  const prompt = isGoogle ? `
You are an expert Google Ads copywriter for JARVIS ADS.

Product Brief: ${JSON.stringify(brief)}
Strategy: ${JSON.stringify(strategy)}
Competitor insights: ${JSON.stringify(intel?.spyfu_data || {}).slice(0, 400)}

Generate Google Ads assets. Return ONLY valid JSON:
{
  "responsive_search_ad": {
    "headlines": ["Headline 1 (max 30 chars)", "Headline 2", "...15 total"],
    "descriptions": ["Description 1 (max 90 chars)", "Description 2", "Description 3", "Description 4"],
    "display_paths": ["path1", "path2"]
  },
  "extensions": {
    "sitelinks": [
      { "title": "...", "desc1": "...", "desc2": "...", "url": "/" }
    ],
    "callouts": ["callout 1", "callout 2", "callout 3", "callout 4"],
    "structured_snippets": { "header": "Services", "values": ["val1", "val2"] }
  },
  "performance_max": {
    "headlines": ["15 headlines max 30 chars each"],
    "long_headlines": ["5 long headlines max 90 chars each"],
    "descriptions": ["4 descriptions max 90 chars each"],
    "business_name": "...",
    "final_url": "${project?.product_url}"
  },
  "video_scripts": {
    "bumper_15s": "Hook (5s) + Key benefit (5s) + CTA (5s)...",
    "skippable_30s": "Full 30-second script with timestamps...",
    "shorts_60s": "60-second vertical format script..."
  }
}` : `
You are an expert Facebook/Instagram Ads copywriter for JARVIS ADS.

Product Brief: ${JSON.stringify(brief)}
Strategy: ${JSON.stringify(strategy)}
Competitor insights: ${JSON.stringify(intel?.fb_competitor_ads || {}).slice(0, 400)}

Generate ad copy. Return ONLY valid JSON:
{
  "copies": [
    {
      "type": "short",
      "primary_text": "...(max 125 chars for feed)",
      "headline": "...",
      "description": "...",
      "cta": "SHOP_NOW"
    },
    {
      "type": "medium",
      "primary_text": "...(150-300 chars)",
      "headline": "...",
      "description": "...",
      "cta": "LEARN_MORE"
    },
    {
      "type": "long",
      "primary_text": "...(300-500 chars with storytelling)",
      "headline": "...",
      "description": "...",
      "cta": "SIGN_UP"
    }
  ],
  "headlines": ["headline 1", "headline 2", "...5 total"],
  "ctas": ["CTA option 1", "CTA option 2", "CTA option 3"],
  "video_script": {
    "hook": "First 3 seconds (stops the scroll)...",
    "body": "Seconds 3-25 (problem + solution + proof)...",
    "cta": "Seconds 25-30 (clear call to action)...",
    "narration": "Full voiceover text for ElevenLabs..."
  }
}`

  const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': claudeKey.encrypted_key,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: 'claude-opus-4-5',
      max_tokens: 2048,
      messages: [{ role: 'user', content: prompt }],
    }),
  })

  const claudeData = await claudeRes.json()
  const rawText = claudeData.content?.[0]?.text || '{}'

  let copyData: Record<string, unknown>
  try {
    const cleaned = rawText.replace(/```json\n?|\n?```/g, '').trim()
    copyData = JSON.parse(cleaned)
  } catch {
    copyData = { error: 'Failed to parse copy' }
  }

  // Save to creatives table
  await supabase.from('creatives').insert({
    project_id,
    type: 'text',
    platform,
    content_text: JSON.stringify(copyData),
    api_used: 'claude',
    approved: false,
  })

  // Log usage
  await supabase.rpc('increment_api_calls', { service: 'anthropic' }).catch(() => {})

  return new Response(
    JSON.stringify({ success: true, copy: copyData }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
})
