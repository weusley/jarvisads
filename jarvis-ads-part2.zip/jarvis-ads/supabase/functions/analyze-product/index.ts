// supabase/functions/analyze-product/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const authHeader = req.headers.get('Authorization')!
  const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''))
  if (!user) return new Response('Unauthorized', { status: 401 })

  const { project_id, product_url } = await req.json()

  // Get Claude API key
  const { data: claudeKey } = await supabase
    .from('system_api_keys')
    .select('encrypted_key')
    .eq('service_name', 'anthropic')
    .eq('status', 'active')
    .single()

  if (!claudeKey) {
    return new Response(JSON.stringify({ error: 'Claude API not configured' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  // Get intelligence data already gathered
  const { data: intel } = await supabase
    .from('project_intelligence')
    .select('*')
    .eq('project_id', project_id)
    .single()

  const perplexityInsights = intel?.perplexity_insights || ''
  const semrushData = intel?.semrush_data ? JSON.stringify(intel.semrush_data).slice(0, 500) : ''
  const similarwebData = intel?.similarweb_data ? JSON.stringify(intel.similarweb_data).slice(0, 500) : ''

  const prompt = `You are JARVIS ADS, an expert digital marketing analyst.

Analyze this product website and return a detailed product brief in JSON format.

Website URL: ${product_url}

Intelligence gathered so far:
- Perplexity insights: ${perplexityInsights}
- SEMrush data: ${semrushData}
- SimilarWeb data: ${similarwebData}

Return ONLY a valid JSON object (no markdown, no explanation) with this exact structure:
{
  "product_name": "...",
  "category": "...",
  "niche": "...",
  "sub_niche": "...",
  "target_audience": "...",
  "age_range": "e.g. 25-44",
  "gender": "e.g. 70% female",
  "price_point": "e.g. R$197 one-time",
  "offer_type": "e.g. digital course, physical product, SaaS, service",
  "main_usps": ["USP 1", "USP 2", "USP 3"],
  "tone_of_voice": "e.g. aspirational, authoritative, empathetic",
  "market_size": "e.g. Large — 2.3M monthly searches in Brazil",
  "growth_trend": "e.g. Growing 18% YoY based on recent data",
  "site_quality_notes": "Brief UX/conversion notes for ad landing pages"
}`

  const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': claudeKey.encrypted_key,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: 'claude-opus-4-5',
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }],
    }),
  })

  const claudeData = await claudeRes.json()
  const rawText = claudeData.content?.[0]?.text || '{}'

  let brief: Record<string, unknown>
  try {
    const cleaned = rawText.replace(/```json\n?|\n?```/g, '').trim()
    brief = JSON.parse(cleaned)
  } catch {
    brief = { product_name: 'Unknown', category: 'Unknown', niche: 'Unknown' }
  }

  // Update project with brief
  await supabase.from('projects').update({
    brief_json: brief,
    product_name: brief.product_name as string,
    status: 'strategy',
    current_step: 1,
  }).eq('id', project_id)

  return new Response(
    JSON.stringify({ success: true, brief }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
})
