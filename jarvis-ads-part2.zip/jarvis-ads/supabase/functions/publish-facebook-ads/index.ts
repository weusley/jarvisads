// supabase/functions/publish-facebook-ads/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const FB_API_VERSION = 'v18.0'

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const authHeader = req.headers.get('Authorization')!
  const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''))
  if (!user) return new Response('Unauthorized', { status: 401 })

  const { project_id, campaign_config } = await req.json()

  // Get user's Facebook API keys
  const { data: fbKey } = await supabase
    .from('api_keys')
    .select('encrypted_key, extra_data')
    .eq('user_id', user.id)
    .eq('service_name', 'facebook_ads')
    .eq('status', 'active')
    .single()

  if (!fbKey) {
    return new Response(
      JSON.stringify({ error: 'Facebook Ads API not configured. Go to API Keys settings.' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  const accessToken = fbKey.encrypted_key
  const adAccountId = fbKey.extra_data?.ad_account_id

  if (!adAccountId) {
    return new Response(
      JSON.stringify({ error: 'Ad Account ID not configured' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  // Get approved creatives
  const { data: creatives } = await supabase
    .from('creatives')
    .select('*')
    .eq('project_id', project_id)
    .in('platform', ['facebook', 'both'])
    .eq('approved', true)

  try {
    // 1. Create Campaign
    const campaignRes = await fetch(
      `https://graph.facebook.com/${FB_API_VERSION}/${adAccountId}/campaigns`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          access_token: accessToken,
          name: campaign_config.name,
          objective: campaign_config.objective || 'OUTCOME_TRAFFIC',
          status: campaign_config.status || 'PAUSED',
          special_ad_categories: [],
        }),
      }
    )
    const campaignData = await campaignRes.json()
    if (campaignData.error) throw new Error(campaignData.error.message)
    const campaignId = campaignData.id

    // 2. Create Ad Set
    const adSetRes = await fetch(
      `https://graph.facebook.com/${FB_API_VERSION}/${adAccountId}/adsets`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          access_token: accessToken,
          name: `${campaign_config.name} - Ad Set`,
          campaign_id: campaignId,
          daily_budget: Math.round(campaign_config.daily_budget * 100), // cents
          billing_event: 'IMPRESSIONS',
          optimization_goal: 'LINK_CLICKS',
          bid_strategy: 'LOWEST_COST_WITHOUT_CAP',
          targeting: {
            age_min: campaign_config.audience?.age_min || 25,
            age_max: campaign_config.audience?.age_max || 54,
            genders: campaign_config.audience?.genders || [1, 2],
            geo_locations: {
              countries: campaign_config.audience?.countries || ['BR'],
            },
            publisher_platforms: campaign_config.placements?.platforms || ['facebook', 'instagram'],
            facebook_positions: campaign_config.placements?.facebook || ['feed', 'story'],
            instagram_positions: campaign_config.placements?.instagram || ['stream', 'story', 'reels'],
          },
          status: 'PAUSED',
          start_time: campaign_config.start_date || new Date().toISOString(),
        }),
      }
    )
    const adSetData = await adSetRes.json()
    if (adSetData.error) throw new Error(adSetData.error.message)
    const adSetId = adSetData.id

    // 3. Create Ads for each approved creative
    const adIds: string[] = []
    const textCreative = creatives?.find(c => c.type === 'text')
    const imageCreatives = creatives?.filter(c => c.type === 'image') || []

    const copyData = textCreative?.content_text ? JSON.parse(textCreative.content_text) : {}
    const primaryCopy = copyData.copies?.[0] || {}

    for (const imgCreative of imageCreatives.slice(0, 3)) {
      const adCreativeRes = await fetch(
        `https://graph.facebook.com/${FB_API_VERSION}/${adAccountId}/adcreatives`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            access_token: accessToken,
            name: `Creative - ${imgCreative.id.slice(0, 8)}`,
            object_story_spec: {
              page_id: campaign_config.page_id,
              link_data: {
                image_url: imgCreative.content_url,
                link: campaign_config.destination_url,
                message: primaryCopy.primary_text || '',
                name: primaryCopy.headline || '',
                description: primaryCopy.description || '',
                call_to_action: {
                  type: primaryCopy.cta || 'LEARN_MORE',
                },
              },
            },
          }),
        }
      )
      const adCreativeData = await adCreativeRes.json()

      if (!adCreativeData.error) {
        const adRes = await fetch(
          `https://graph.facebook.com/${FB_API_VERSION}/${adAccountId}/ads`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              access_token: accessToken,
              name: `Ad - ${imgCreative.id.slice(0, 8)}`,
              adset_id: adSetId,
              creative: { creative_id: adCreativeData.id },
              status: 'PAUSED',
              tracking_specs: [{
                'action.type': ['offsite_conversion'],
                fb_pixel: campaign_config.pixel_id ? [campaign_config.pixel_id] : undefined,
              }],
            }),
          }
        )
        const adData = await adRes.json()
        if (adData.id) adIds.push(adData.id)
      }
    }

    // Save campaign to DB
    await supabase.from('campaigns').insert({
      project_id,
      platform: 'facebook',
      fb_campaign_id: campaignId,
      campaign_name: campaign_config.name,
      status: 'draft',
      budget: campaign_config.daily_budget,
      budget_type: 'daily',
    })

    // Update project step
    await supabase.from('projects').update({ current_step: 6, status: 'publishing' }).eq('id', project_id)

    return new Response(
      JSON.stringify({
        success: true,
        campaign_id: campaignId,
        ad_set_id: adSetId,
        ad_ids: adIds,
        ads_manager_url: `https://business.facebook.com/adsmanager/manage/campaigns?act=${adAccountId.replace('act_', '')}&selected_campaign_ids=${campaignId}`,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
