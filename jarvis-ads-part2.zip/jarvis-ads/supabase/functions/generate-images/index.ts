// supabase/functions/generate-images/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const authHeader = req.headers.get('Authorization')!
  const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''))
  if (!user) return new Response('Unauthorized', { status: 401 })

  const { project_id, prompt: userPrompt, style, platform } = await req.json()

  // Get available image API keys
  const { data: keys } = await supabase
    .from('system_api_keys')
    .select('service_name, encrypted_key')
    .in('service_name', ['openai', 'leonardo', 'stability'])
    .eq('status', 'active')

  const keyMap: Record<string, string> = {}
  keys?.forEach(k => { keyMap[k.service_name] = k.encrypted_key })

  let images: string[] = []
  let apiUsed = ''

  // Priority: Leonardo.ai > DALL-E 3 > Stability AI
  if (keyMap.leonardo) {
    try {
      // Leonardo.ai generation
      const genRes = await fetch('https://cloud.leonardo.ai/api/rest/v1/generations', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${keyMap.leonardo}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: userPrompt,
          modelId: 'b24e16ff-06e3-43eb-8d33-4416c2d75876', // Leonardo Creative
          width: 1024,
          height: 1024,
          num_images: 4,
          guidance_scale: 7,
        }),
      })
      const genData = await genRes.json()
      const generationId = genData.sdGenerationJob?.generationId

      if (generationId) {
        // Poll for completion
        await new Promise(r => setTimeout(r, 5000))
        const resultRes = await fetch(`https://cloud.leonardo.ai/api/rest/v1/generations/${generationId}`, {
          headers: { 'Authorization': `Bearer ${keyMap.leonardo}` },
        })
        const resultData = await resultRes.json()
        images = resultData.generations_by_pk?.generated_images?.map((img: { url: string }) => img.url) || []
        apiUsed = 'leonardo'
      }
    } catch (e) {
      console.error('Leonardo failed:', e)
    }
  }

  if (images.length === 0 && keyMap.openai) {
    try {
      // DALL-E 3
      const dalleRes = await fetch('https://api.openai.com/v1/images/generations', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${keyMap.openai}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'dall-e-3',
          prompt: userPrompt,
          n: 1,
          size: '1024x1024',
          quality: 'hd',
        }),
      })
      const dalleData = await dalleRes.json()
      images = dalleData.data?.map((img: { url: string }) => img.url) || []
      apiUsed = 'dall-e-3'
    } catch (e) {
      console.error('DALL-E failed:', e)
    }
  }

  if (images.length === 0 && keyMap.stability) {
    try {
      // Stability AI
      const stabRes = await fetch('https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${keyMap.stability}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text_prompts: [{ text: userPrompt, weight: 1 }],
          cfg_scale: 7,
          height: 1024,
          width: 1024,
          samples: 4,
          steps: 30,
        }),
      })
      const stabData = await stabRes.json()
      images = stabData.artifacts?.map((img: { base64: string }) =>
        `data:image/png;base64,${img.base64}`
      ) || []
      apiUsed = 'stability-ai'
    } catch (e) {
      console.error('Stability AI failed:', e)
    }
  }

  // Remove background with remove.bg on first image (if configured)
  const { data: removebgKey } = await supabase
    .from('system_api_keys')
    .select('encrypted_key')
    .eq('service_name', 'removebg')
    .eq('status', 'active')
    .single()

  let cleanImages = images
  if (removebgKey && images.length > 0 && images[0].startsWith('http')) {
    try {
      const rbRes = await fetch('https://api.remove.bg/v1.0/removebg', {
        method: 'POST',
        headers: {
          'X-Api-Key': removebgKey.encrypted_key,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image_url: images[0], size: 'auto' }),
      })
      if (rbRes.ok) {
        const blob = await rbRes.blob()
        const arrayBuffer = await blob.arrayBuffer()
        const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)))
        cleanImages = [`data:image/png;base64,${base64}`, ...images.slice(1)]
      }
    } catch { /* skip remove.bg */ }
  }

  // Save to creatives
  for (const imageUrl of cleanImages) {
    await supabase.from('creatives').insert({
      project_id,
      type: 'image',
      platform: platform || 'both',
      content_url: imageUrl,
      metadata: { prompt: userPrompt, style },
      api_used: apiUsed,
      approved: false,
    })
  }

  await supabase.rpc('increment_api_calls', { service: apiUsed }).catch(() => {})

  return new Response(
    JSON.stringify({ success: true, images: cleanImages, api_used: apiUsed }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
})
