// supabase/functions/publish-google-ads/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const authHeader = req.headers.get('Authorization')!
  const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''))
  if (!user) return new Response('Unauthorized', { status: 401 })

  const { project_id, campaign_config } = await req.json()

  // Get user's Google Ads connection
  const { data: googleConn } = await supabase
    .from('google_ads_connections')
    .select('*')
    .eq('user_id', user.id)
    .single()

  if (!googleConn?.refresh_token_encrypted) {
    return new Response(
      JSON.stringify({ error: 'Google Ads not connected. Connect via OAuth in API Keys.' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  // Get system developer token
  const { data: devTokenRow } = await supabase
    .from('system_api_keys')
    .select('encrypted_key')
    .eq('service_name', 'google_ads_developer_token')
    .single()

  if (!devTokenRow) {
    return new Response(
      JSON.stringify({ error: 'Google Ads developer token not configured by admin' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  // Refresh OAuth token
  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: Deno.env.get('GOOGLE_CLIENT_ID')!,
      client_secret: Deno.env.get('GOOGLE_CLIENT_SECRET')!,
      refresh_token: googleConn.refresh_token_encrypted,
      grant_type: 'refresh_token',
    }),
  })
  const tokenData = await tokenRes.json()
  const accessToken = tokenData.access_token

  if (!accessToken) {
    return new Response(
      JSON.stringify({ error: 'Failed to refresh Google OAuth token. Reconnect in API Keys.' }),
      { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  const customerId = googleConn.customer_id
  const developerToken = devTokenRow.encrypted_key

  const headers = {
    'Authorization': `Bearer ${accessToken}`,
    'developer-token': developerToken,
    'login-customer-id': customerId,
    'Content-Type': 'application/json',
  }

  const baseUrl = `https://googleads.googleapis.com/v15/customers/${customerId}`

  // Get approved creatives
  const { data: creatives } = await supabase
    .from('creatives')
    .select('*')
    .eq('project_id', project_id)
    .in('platform', ['google', 'both'])
    .eq('approved', true)

  const textCreative = creatives?.find(c => c.type === 'text')
  const copyData = textCreative?.content_text ? JSON.parse(textCreative.content_text) : {}

  try {
    // 1. Create Campaign Budget
    const budgetRes = await fetch(`${baseUrl}/campaignBudgets:mutate`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        operations: [{
          create: {
            name: `Budget for ${campaign_config.name}`,
            deliveryMethod: 'STANDARD',
            amountMicros: Math.round(campaign_config.daily_budget * 1_000_000),
            explicitlyShared: false,
          },
        }],
      }),
    })
    const budgetData = await budgetRes.json()
    const budgetResourceName = budgetData.results?.[0]?.resourceName
    if (!budgetResourceName) throw new Error('Failed to create budget')

    // 2. Create Campaign
    const campaignRes = await fetch(`${baseUrl}/campaigns:mutate`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        operations: [{
          create: {
            name: campaign_config.name,
            status: 'PAUSED',
            advertisingChannelType: campaign_config.campaign_type === 'PERFORMANCE_MAX'
              ? 'PERFORMANCE_MAX'
              : 'SEARCH',
            campaignBudget: budgetResourceName,
            biddingStrategyType: campaign_config.bidding_strategy || 'MAXIMIZE_CONVERSIONS',
            targetCpa: campaign_config.target_cpa ? {
              targetCpaMicros: Math.round(campaign_config.target_cpa * 1_000_000),
            } : undefined,
            geoTargetTypeSetting: {
              positiveGeoTargetType: 'PRESENCE_OR_INTEREST',
            },
            startDate: new Date().toISOString().split('T')[0].replace(/-/g, ''),
          },
        }],
      }),
    })
    const campaignData = await campaignRes.json()
    const campaignResourceName = campaignData.results?.[0]?.resourceName
    if (!campaignResourceName) throw new Error('Failed to create campaign')
    const campaignId = campaignResourceName.split('/').pop()

    // 3. Create Ad Group (for Search campaigns)
    let adGroupResourceName = ''
    if (campaign_config.campaign_type !== 'PERFORMANCE_MAX') {
      const adGroupRes = await fetch(`${baseUrl}/adGroups:mutate`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          operations: [{
            create: {
              name: `${campaign_config.name} - Ad Group`,
              campaign: campaignResourceName,
              status: 'ENABLED',
              type: 'SEARCH_STANDARD',
              cpcBidMicros: 1_000_000, // $1 default CPC
            },
          }],
        }),
      })
      const adGroupData = await adGroupRes.json()
      adGroupResourceName = adGroupData.results?.[0]?.resourceName || ''
    }

    // 4. Create RSA Ad (for Search campaigns)
    if (adGroupResourceName && copyData.responsive_search_ad) {
      const rsa = copyData.responsive_search_ad
      await fetch(`${baseUrl}/ads:mutate`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          operations: [{
            create: {
              finalUrls: [campaign_config.destination_url],
              responsiveSearchAd: {
                headlines: (rsa.headlines || []).slice(0, 15).map((text: string) => ({ text })),
                descriptions: (rsa.descriptions || []).slice(0, 4).map((text: string) => ({ text })),
                path1: rsa.display_paths?.[0] || '',
                path2: rsa.display_paths?.[1] || '',
              },
            },
          }],
        }),
      })
    }

    // 5. Create Keywords (for Search campaigns)
    if (adGroupResourceName && campaign_config.keywords?.length > 0) {
      const keywordOps = campaign_config.keywords.slice(0, 20).map((kw: { text: string; match_type: string }) => ({
        create: {
          adGroup: adGroupResourceName,
          text: kw.text,
          matchType: kw.match_type || 'BROAD',
          status: 'ENABLED',
        },
      }))

      await fetch(`${baseUrl}/adGroupCriteria:mutate`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ operations: keywordOps }),
      })
    }

    // Save campaign to DB
    await supabase.from('campaigns').insert({
      project_id,
      platform: 'google',
      google_campaign_id: campaignId,
      campaign_name: campaign_config.name,
      status: 'draft',
      budget: campaign_config.daily_budget,
      budget_type: 'daily',
    })

    return new Response(
      JSON.stringify({
        success: true,
        campaign_id: campaignId,
        campaign_resource_name: campaignResourceName,
        google_ads_url: `https://ads.google.com/aw/campaigns?campaignId=${campaignId}`,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
